import React, { useState, useRef, useEffect } from 'react';
import { Camera, Send, X, Plus, Home, Grid, Film, User, Heart, MessageCircle, Share2, Bookmark, Sparkles, ArrowLeft, Zap, Target, Grid3x3, Clock, ChevronRight, Trophy, Play, RefreshCw, ArrowUp, ArrowDown, ArrowRight, Code, TrendingUp, Calculator, MessageSquare, Image, Save, FolderOpen, Trash2, Edit3, Upload, Wand2, Video, Repeat, Check, Package } from 'lucide-react';
import { deckCards, getCardById, getCardRarity, getCardDeck, getAllCardsForDeck } from '../data/cards';
import ReactMarkdown from 'react-markdown';

interface UserCard {
  id: string;
  userId: string;
  cardId: number;
  quantity: number;
}

interface Trade {
  id: string;
  fromUserId: string;
  toUserId: string | null;
  offeredCardIds: number[];
  requestedCardIds: number[] | null;
  status: string;
  createdAt: string;
}

interface SavedChat {
  id: string;
  name: string;
  topic: string;
  messages: any[];
  createdAt: number;
  updatedAt: number;
}

export default function PicDeckPlatform() {
  const [currentScreen, setCurrentScreen] = useState('landing');
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [verificationCode, setVerificationCode] = useState('');
  const [sentCode, setSentCode] = useState('');
  const [authError, setAuthError] = useState('');
  const [authLoading, setAuthLoading] = useState(false);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  const [showPackAnimation, setShowPackAnimation] = useState(false);
  const [newCard, setNewCard] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('home');
  const [aiInput, setAiInput] = useState('');
  const [aiMessages, setAiMessages] = useState<any[]>([]);
  const [aiTyping, setAiTyping] = useState(false);
  const [activeAiTopic, setActiveAiTopic] = useState('General');
  const [activeChat, setActiveChat] = useState<any>(null);
  const [messageInput, setMessageInput] = useState('');
  const [activeGame, setActiveGame] = useState<string | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Saved chats state
  const [savedChats, setSavedChats] = useState<SavedChat[]>([]);
  const [currentSavedChatId, setCurrentSavedChatId] = useState<string | null>(null);
  const [showSaveDialog, setShowSaveDialog] = useState(false);
  const [showSavedSessions, setShowSavedSessions] = useState(false);
  const [chatNameInput, setChatNameInput] = useState('');

  // Feed state
  const [feedMode, setFeedMode] = useState<'posts' | 'reels'>('posts');
  const [reels, setReels] = useState<any[]>([]);
  const [feedPosts, setFeedPosts] = useState<any[]>([]);

  // Photo/Video Editor state
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [uploadedVideo, setUploadedVideo] = useState<string | null>(null);
  const [editStyle, setEditStyle] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [editedImage, setEditedImage] = useState<string | null>(null);
  const [editMediaType, setEditMediaType] = useState<'photo' | 'video'>('photo');
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);

  // Card collection and trading state
  const [userCards, setUserCards] = useState<UserCard[]>([]);
  const [trades, setTrades] = useState<Trade[]>([]);
  const [allUsers, setAllUsers] = useState<any[]>([]);
  const [profileTab, setProfileTab] = useState<'stats' | 'collection' | 'trading' | 'settings'>('stats');
  const [showCreateTrade, setShowCreateTrade] = useState(false);
  const [selectedTradeCards, setSelectedTradeCards] = useState<number[]>([]);
  const [collectionFilter, setCollectionFilter] = useState<string>('all');

  // Story users data
  const storyUsers = [
    { name: 'Alex', avatar: '🏀', hasStory: true },
    { name: 'Jordan', avatar: '🎮', hasStory: true },
    { name: 'Taylor', avatar: '🎨', hasStory: true },
    { name: 'Casey', avatar: '🎸', hasStory: false },
    { name: 'Morgan', avatar: '📸', hasStory: true },
    { name: 'Riley', avatar: '🏎️', hasStory: true },
    { name: 'Quinn', avatar: '💻', hasStory: false },
  ];

  // Initialize feed data
  useEffect(() => {
    const initialPosts = [
      { id: 1, user: 'card_collector', avatar: '🎴', image: '🏆', location: 'Card Shop', caption: 'Just pulled my first Legendary! This collection is insane 🔥', likes: 1247, comments: 89, time: '2 hours ago', liked: false },
      { id: 2, user: 'gamer_pro', avatar: '🎮', image: '🎯', location: 'Gaming Arena', caption: 'Beat my snake high score! Who can beat 450? 🐍', likes: 892, comments: 156, time: '4 hours ago', liked: false },
      { id: 3, user: 'tech_wizard', avatar: '💻', image: '✨', location: 'Silicon Valley', caption: 'The AI assistant in this app is actually insane. Asked it to explain quantum computing and it nailed it', likes: 2341, comments: 203, time: '6 hours ago', liked: false },
      { id: 4, user: 'sports_fan', avatar: '⚽', image: '🏅', location: 'Stadium', caption: 'Got the rare Messi card!!! Only 1 in a million chance 🤯', likes: 5672, comments: 412, time: '8 hours ago', liked: false },
      { id: 5, user: 'art_lover', avatar: '🎨', image: '🖼️', location: 'Art Gallery', caption: 'The card designs in this app are beautiful. Collecting all the Artist cards', likes: 743, comments: 67, time: '12 hours ago', liked: false },
    ];
    setFeedPosts(initialPosts);

    const initialReels = generateReels(10);
    setReels(initialReels);
  }, []);

  const generateReels = (count: number, startId = 0) => {
    const reelData = [
      { avatar: '🏀', user: 'hoops_daily', caption: 'Insane dunk compilation 🏀🔥', music: 'Original Sound - hoops_daily', image: '🏀' },
      { avatar: '🎮', user: 'gaming_clips', caption: 'When you finally beat the boss 💪', music: 'Victory Theme - Gaming', image: '🎮' },
      { avatar: '🚗', user: 'car_culture', caption: 'This engine sound though 🔊', music: 'Car Sounds - Viral', image: '🏎️' },
      { avatar: '🎵', user: 'music_vibes', caption: 'This beat hits different', music: 'Trending Track 2024', image: '🎵' },
      { avatar: '🍳', user: 'chef_life', caption: 'Wait for the flip 👨‍🍳', music: 'Cooking Beats', image: '🍳' },
      { avatar: '🏋️', user: 'fitness_goals', caption: 'Morning routine 💪', music: 'Workout Mix', image: '💪' },
      { avatar: '🎨', user: 'art_process', caption: 'Watch me create ✨', music: 'Lo-Fi Beats', image: '🎨' },
      { avatar: '🐕', user: 'pet_moments', caption: 'When you say "walk" 🐕', music: 'Happy Vibes', image: '🐕' },
      { avatar: '✈️', user: 'travel_diary', caption: 'POV: Landing in paradise', music: 'Travel Vibes', image: '✈️' },
      { avatar: '💄', user: 'glam_looks', caption: 'Get ready with me 💅', music: 'Glam Sound', image: '💄' },
    ];
    
    return Array.from({ length: count }, (_, i) => {
      const data = reelData[(startId + i) % reelData.length];
      return {
        id: startId + i + 1,
        ...data,
        likes: Math.floor(Math.random() * 50000) + 1000,
        comments: Math.floor(Math.random() * 500) + 50,
        liked: false,
      };
    });
  };

  const formatNumber = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const likeFeedPost = (postId: number) => {
    setFeedPosts(prev => prev.map(post => 
      post.id === postId 
        ? { ...post, liked: !post.liked, likes: post.liked ? post.likes - 1 : post.likes + 1 }
        : post
    ));
  };

  const likeReel = (reelId: number) => {
    setReels(prev => prev.map(reel => 
      reel.id === reelId 
        ? { ...reel, liked: !reel.liked, likes: reel.liked ? reel.likes - 1 : reel.likes + 1 }
        : reel
    ));
  };

  const loadMoreReels = () => {
    const newReels = generateReels(10, reels.length);
    setReels(prev => [...prev, ...newReels]);
  };

  const [signUpData, setSignUpData] = useState({
    name: '',
    username: '',
    email: '',
    birthDate: '',
    selectedDeck: '',
    password: ''
  });

  const [loginData, setLoginData] = useState({
    email: '',
    password: ''
  });

  const [userProfile, setUserProfile] = useState<any>({
    name: 'Demo User',
    age: 20,
    picCount: 0,
    packsAvailable: 1,
    selectedDeck: 'Athletes',
    collection: [],
    completionRate: 0
  });

  const [posts, setPosts] = useState([
    { 
      id: 1, 
      user: 'PicDeck', 
      avatar: '💬', 
      content: 'Welcome to PicDeck! Real people only. Start collecting cards! 🎉',
      likes: 0,
      comments: 0,
      shares: 0,
      time: 'Now',
      liked: false
    }
  ]);

  const [chats, setChats] = useState([
    { id: 1, name: 'CardMaster', avatar: '🎯', lastMessage: 'Want to trade cards?', time: '2m', unread: 1, messages: [
      { id: 1, text: 'Hey! Nice collection!', sender: 'them', time: '5m ago' },
      { id: 2, text: 'Want to trade cards?', sender: 'them', time: '2m ago' }
    ]},
    { id: 2, name: 'GameChamp', avatar: '🏆', lastMessage: 'Beat my high score!', time: '1h', unread: 0, messages: [
      { id: 1, text: 'Beat my high score!', sender: 'them', time: '1h ago' }
    ]}
  ]);

  // F1 Racing Game State - Endless Runner Style
  const [racingGame, setRacingGame] = useState({
    playerLane: 1,
    score: 0,
    speed: 3,
    gameStarted: false,
    countdown: 3,
    gameOver: false,
    highScore: 0,
    obstacles: [] as {lane: number, y: number, type: 'car' | 'cone' | 'oil'}[],
    boosts: [] as {lane: number, y: number}[],
    nitro: 0,
    nitroActive: false
  });

  // Memory Game State
  const [memoryGame, setMemoryGame] = useState<any>({
    cards: [],
    flipped: [],
    matched: [],
    moves: 0,
    gameOver: false,
    highScore: 0
  });

  // F1 Reaction Game State (5 lights)
  const [reactionGame, setReactionGame] = useState({
    phase: 'idle' as 'idle' | 'countdown' | 'ready' | 'go' | 'result' | 'tooEarly',
    lightsOn: 0,
    startTime: 0,
    reactionTime: 0,
    bestTime: Infinity
  });

  // Number Sequence Game State
  const [sequenceGame, setSequenceGame] = useState<any>({
    sequence: [],
    userSequence: [],
    level: 1,
    showing: false,
    gameOver: false,
    highScore: 0
  });

  // Block Blast Game State (8x8 grid)
  const [blockGame, setBlockGame] = useState({
    grid: Array(8).fill(null).map(() => Array(8).fill(0)) as number[][],
    score: 0,
    highScore: 0,
    gameOver: false,
    currentPieces: [] as {shape: number[][], color: number}[],
    selectedPiece: null as number | null,
    draggingPiece: null as number | null,
    ghostPosition: null as {row: number, col: number} | null,
    clearingCells: [] as {row: number, col: number}[]
  });

  const [leaderboards] = useState({
    racing: [{name: 'Verstappen', score: 12.3}, {name: 'Hamilton', score: 13.1}],
    memory: [{name: 'BrainMaster', score: 8}, {name: 'MemoryKing', score: 12}],
    reaction: [{name: 'QuickDraw', score: 187}, {name: 'Lightning', score: 203}],
    blocks: [{name: 'BlockMaster', score: 5000}, {name: 'TetrisPro', score: 4200}]
  });

  const aiTopics = [
    { id: 'General', icon: <MessageSquare className="w-4 h-4" />, color: 'bg-blue-500' },
    { id: 'Coding', icon: <Code className="w-4 h-4" />, color: 'bg-purple-500' },
    { id: 'Investing', icon: <TrendingUp className="w-4 h-4" />, color: 'bg-green-500' },
    { id: 'Math', icon: <Calculator className="w-4 h-4" />, color: 'bg-orange-500' },
    { id: 'Image', icon: <Image className="w-4 h-4" />, color: 'bg-pink-500' },
    { id: 'Art Studio', icon: <Wand2 className="w-4 h-4" />, color: 'bg-gradient-to-r from-pink-500 to-purple-500' },
  ];

  const editStyles = [
    'Cartoon/Anime',
    'Oil Painting',
    'Watercolor',
    'Sketch/Pencil',
    'Pop Art',
    'Vintage/Retro',
    'Cyberpunk',
    'Fantasy',
    'Minimalist',
    'Neon Glow',
  ];

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setUploadedImage(event.target?.result as string);
        setEditedImage(null);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleVideoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        setUploadedVideo(event.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleEditImage = async () => {
    if (!uploadedImage || !editStyle) return;
    
    setIsEditing(true);
    
    try {
      const response = await fetch('/api/edit-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          image: uploadedImage,
          style: editStyle,
        }),
      });
      
      const data = await response.json();
      
      if (response.ok && data.imageUrl) {
        setEditedImage(data.imageUrl);
      } else {
        alert(data.error || 'Failed to edit image');
      }
    } catch (error) {
      console.error('Edit error:', error);
      alert('Failed to edit image');
    } finally {
      setIsEditing(false);
    }
  };

  const clearUpload = () => {
    setUploadedImage(null);
    setUploadedVideo(null);
    setEditedImage(null);
    setEditStyle('');
  };


  const saveCurrentChat = () => {
    if (aiMessages.length === 0) {
      alert('No messages to save!');
      return;
    }
    const defaultName = `${activeAiTopic} - ${new Date().toLocaleDateString()}`;
    setChatNameInput(defaultName);
    setShowSaveDialog(true);
  };

  const confirmSaveChat = async () => {
    if (!chatNameInput.trim() || !currentUserId) return;

    try {
      if (currentSavedChatId) {
        // Update existing chat in database
        const response = await fetch(`/api/chats/${currentSavedChatId}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: chatNameInput,
            messages: aiMessages,
          }),
        });
        
        if (response.ok) {
          const data = await response.json();
          setSavedChats(prev => prev.map(chat => 
            chat.id === currentSavedChatId 
              ? { ...chat, name: chatNameInput, messages: aiMessages, updatedAt: Date.now() }
              : chat
          ));
        }
      } else {
        // Create new chat in database
        const response = await fetch('/api/chats', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            userId: currentUserId,
            name: chatNameInput,
            topic: activeAiTopic,
            messages: aiMessages,
          }),
        });
        
        if (response.ok) {
          const data = await response.json();
          const newChat: SavedChat = {
            id: data.chat.id,
            name: data.chat.name,
            topic: data.chat.topic,
            messages: data.chat.messages || [],
            createdAt: new Date(data.chat.createdAt).getTime(),
            updatedAt: new Date(data.chat.updatedAt).getTime(),
          };
          setSavedChats(prev => [...prev, newChat]);
          setCurrentSavedChatId(newChat.id);
        }
      }
    } catch (error) {
      console.error('Failed to save chat:', error);
    }
    
    setShowSaveDialog(false);
    setChatNameInput('');
  };

  const loadSavedChat = (chat: SavedChat) => {
    setAiMessages(chat.messages);
    setActiveAiTopic(chat.topic);
    setCurrentSavedChatId(chat.id);
    setShowSavedSessions(false);
  };

  const deleteSavedChat = async (chatId: string) => {
    try {
      await fetch(`/api/chats/${chatId}`, { method: 'DELETE' });
      setSavedChats(prev => prev.filter(chat => chat.id !== chatId));
      if (currentSavedChatId === chatId) {
        setCurrentSavedChatId(null);
      }
    } catch (error) {
      console.error('Failed to delete chat:', error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('picdeck-user');
    setCurrentUserId(null);
    setSavedChats([]);
    setAiMessages([]);
    setCurrentScreen('landing');
  };

  const startNewChat = () => {
    setAiMessages([]);
    setCurrentSavedChatId(null);
    setShowSavedSessions(false);
  };

  const calculateAge = (birthDate: string) => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    return age;
  };

  const handleSignUp = async () => {
    if (!signUpData.name || !signUpData.username || !signUpData.email || !signUpData.birthDate || !signUpData.selectedDeck || !signUpData.password) {
      setAuthError('Please fill in all fields!');
      return;
    }
    
    setAuthLoading(true);
    setAuthError('');
    
    try {
      const response = await fetch('/api/auth/signup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(signUpData),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        setAuthError(data.error || 'Failed to create account');
        return;
      }
      
      // Save user to localStorage for session persistence
      localStorage.setItem('picdeck-user', JSON.stringify(data.user));
      setCurrentUserId(data.user.id);
      
      const age = calculateAge(signUpData.birthDate);
      setUserProfile({
        ...signUpData,
        id: data.user.id,
        age,
        picCount: 0,
        packsAvailable: 1,
        collection: [],
        completionRate: 0
      });
      
      const welcomeMessage = `Hi ${signUpData.name}! I'm your AI assistant. Select a topic above like Coding, Investing, or Math, and I'll help you out!`;
      setAiMessages([{ id: 1, text: welcomeMessage, sender: 'ai' }]);
      setCurrentScreen('main');
    } catch (error) {
      setAuthError('Network error. Please try again.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogin = async () => {
    if (!loginData.email || !loginData.password) {
      setAuthError('Please enter email and password');
      return;
    }
    
    setAuthLoading(true);
    setAuthError('');
    
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(loginData),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        setAuthError(data.error || 'Login failed');
        return;
      }
      
      // Save user to localStorage
      localStorage.setItem('picdeck-user', JSON.stringify(data.user));
      setCurrentUserId(data.user.id);
      
      // Load user profile
      setUserProfile({
        ...data.user,
        age: data.user.birthDate ? calculateAge(data.user.birthDate) : 20,
        picCount: 0,
        packsAvailable: data.user.packsAvailable || 1,
        collection: [],
        completionRate: 0
      });
      
      // Load saved chats, cards, and trades from database
      loadSavedChats(data.user.id);
      loadUserCards(data.user.id);
      loadTrades();
      loadAllUsers();
      
      const welcomeMessage = `Welcome back, ${data.user.name}! Ready to continue where you left off?`;
      setAiMessages([{ id: 1, text: welcomeMessage, sender: 'ai' }]);
      setCurrentScreen('main');
    } catch (error) {
      setAuthError('Network error. Please try again.');
    } finally {
      setAuthLoading(false);
    }
  };

  const loadSavedChats = async (userId: string) => {
    try {
      const response = await fetch(`/api/chats/${userId}`);
      const data = await response.json();
      if (response.ok && data.chats) {
        setSavedChats(data.chats.map((chat: any) => ({
          ...chat,
          messages: chat.messages || [],
          createdAt: new Date(chat.createdAt).getTime(),
          updatedAt: new Date(chat.updatedAt).getTime(),
        })));
      }
    } catch (error) {
      console.error('Failed to load saved chats:', error);
    }
  };

  const loadUserCards = async (userId: string) => {
    try {
      const response = await fetch(`/api/cards/${userId}`);
      const data = await response.json();
      if (response.ok && data.cards) {
        setUserCards(data.cards);
      }
    } catch (error) {
      console.error('Failed to load user cards:', error);
    }
  };

  const loadTrades = async () => {
    try {
      const response = await fetch('/api/trades');
      const data = await response.json();
      if (response.ok && data.trades) {
        setTrades(data.trades);
      }
    } catch (error) {
      console.error('Failed to load trades:', error);
    }
  };

  const loadAllUsers = async () => {
    try {
      const response = await fetch('/api/users');
      const data = await response.json();
      if (response.ok && data.users) {
        setAllUsers(data.users);
      }
    } catch (error) {
      console.error('Failed to load users:', error);
    }
  };

  const saveCardToDatabase = async (cardId: number) => {
    if (!currentUserId) return;
    try {
      await fetch(`/api/cards/${currentUserId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cardId }),
      });
      loadUserCards(currentUserId);
    } catch (error) {
      console.error('Failed to save card:', error);
    }
  };

  const updateSelectedDeck = async (deck: string) => {
    if (!currentUserId) return;
    try {
      const response = await fetch(`/api/users/${currentUserId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ selectedDeck: deck }),
      });
      if (response.ok) {
        setUserProfile((prev: any) => ({ ...prev, selectedDeck: deck }));
        const storedUser = localStorage.getItem('picdeck-user');
        if (storedUser) {
          const user = JSON.parse(storedUser);
          user.selectedDeck = deck;
          localStorage.setItem('picdeck-user', JSON.stringify(user));
        }
      }
    } catch (error) {
      console.error('Failed to update deck:', error);
    }
  };

  const createTrade = async () => {
    if (!currentUserId || selectedTradeCards.length === 0) return;
    try {
      const response = await fetch('/api/trades', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fromUserId: currentUserId,
          offeredCardIds: selectedTradeCards,
        }),
      });
      if (response.ok) {
        setSelectedTradeCards([]);
        setShowCreateTrade(false);
        loadTrades();
      }
    } catch (error) {
      console.error('Failed to create trade:', error);
    }
  };

  const acceptTrade = async (tradeId: string) => {
    if (!currentUserId) return;
    try {
      const response = await fetch(`/api/trades/${tradeId}/accept`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ acceptingUserId: currentUserId }),
      });
      if (response.ok) {
        loadTrades();
        loadUserCards(currentUserId);
      }
    } catch (error) {
      console.error('Failed to accept trade:', error);
    }
  };

  const cancelTrade = async (tradeId: string) => {
    try {
      await fetch(`/api/trades/${tradeId}`, { method: 'DELETE' });
      loadTrades();
    } catch (error) {
      console.error('Failed to cancel trade:', error);
    }
  };

  // Check for existing session on mount
  useEffect(() => {
    const storedUser = localStorage.getItem('picdeck-user');
    if (storedUser) {
      try {
        const user = JSON.parse(storedUser);
        setCurrentUserId(user.id);
        setUserProfile({
          ...user,
          age: user.birthDate ? calculateAge(user.birthDate) : 20,
          picCount: 0,
          packsAvailable: user.packsAvailable || 1,
          collection: [],
          completionRate: 0
        });
        loadSavedChats(user.id);
        loadUserCards(user.id);
        loadTrades();
        loadAllUsers();
        setCurrentScreen('main');
      } catch (e) {
        localStorage.removeItem('picdeck-user');
      }
    }
  }, []);

  const handleVerification = () => {
    if (verificationCode === sentCode) {
      const age = calculateAge(signUpData.birthDate);
      setUserProfile({
        ...signUpData,
        age,
        picCount: 0,
        packsAvailable: 1,
        collection: [],
        completionRate: 0
      });
      
      const welcomeMessage = `Hi ${signUpData.name}! I'm your AI assistant. Select a topic above like Coding, Investing, or Math, and I'll help you out!`;
      
      setAiMessages([{ id: 1, text: welcomeMessage, sender: 'ai' }]);
      setCurrentScreen('main');
    } else {
      alert('Incorrect verification code!');
    }
  };

  const openPack = async () => {
    if (userProfile.packsAvailable > 0 && currentUserId) {
      // @ts-ignore
      const deck = deckCards[userProfile.selectedDeck];
      const rand = Math.random() * 1000000;
      let rarity = 'common';
      if (rand < 1) rarity = 'oneInMillion';
      else if (rand < 1000) rarity = 'iconic';
      else if (rand < 5000) rarity = 'legendary';
      else if (rand < 100000) rarity = 'epic';
      else if (rand < 350000) rarity = 'rare';
      
      const cardsOfRarity = deck[rarity];
      const randomCard = cardsOfRarity[Math.floor(Math.random() * cardsOfRarity.length)];
      
      setNewCard({ ...randomCard, rarity, deck: userProfile.selectedDeck });
      setShowPackAnimation(true);
      
      // Save card to database first, then update local state
      try {
        const response = await fetch(`/api/cards/${currentUserId}`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ cardId: randomCard.id }),
        });
        
        if (response.ok) {
          // Success - update local state and reload cards
          setUserProfile((prev: any) => ({
            ...prev,
            packsAvailable: prev.packsAvailable - 1,
            collection: [...prev.collection, { ...randomCard, rarity, id: Date.now() }],
            completionRate: Math.min(100, prev.completionRate + 5)
          }));
          loadUserCards(currentUserId);
        } else {
          console.error('Failed to save card - server error');
        }
      } catch (error) {
        console.error('Failed to save card:', error);
      }
      
      setTimeout(() => {
        setShowPackAnimation(false);
        setNewCard(null);
      }, 3000);
    }
  };

  const sendAiMessage = async () => {
    if (!aiInput.trim()) return;
    
    const userMsg = { id: Date.now(), text: aiInput, sender: 'user' };
    setAiMessages(prev => [...prev, userMsg]);
    const query = aiInput;
    setAiInput('');
    setAiTyping(true);

    try {
      // Handle image generation
      if (activeAiTopic === 'Image') {
        const response = await fetch('/api/generate-image', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            prompt: query,
          }),
        });

        if (!response.ok) {
          throw new Error('Failed to generate image');
        }

        const data = await response.json();
        setAiMessages(prev => [...prev, { 
          id: Date.now(), 
          text: `Here's what I created for "${query}"`, 
          image: data.imageUrl,
          sender: 'ai' 
        }]);
      } else {
        // Handle regular chat
        const response = await fetch('/api/chat', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            message: query,
            topic: activeAiTopic,
          }),
        });

        if (!response.ok) {
          throw new Error('Failed to get AI response');
        }

        const data = await response.json();
        const responseText = data.response;
        
        setAiMessages(prev => [...prev, { id: Date.now(), text: responseText, sender: 'ai' }]);
      }
    } catch (error) {
      console.error('AI chat error:', error);
      setAiMessages(prev => [...prev, { 
        id: Date.now(), 
        text: "Sorry, I'm having trouble connecting right now. Please try again!", 
        sender: 'ai' 
      }]);
    } finally {
      setAiTyping(false);
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  };

  const sendChatMessage = () => {
    if (!messageInput.trim() || !activeChat) return;
    
    const newMessage = {
      id: Date.now(),
      text: messageInput,
      sender: 'user',
      time: 'Just now'
    };
    
    setChats(prev => prev.map(chat => 
      chat.id === activeChat.id 
        ? { ...chat, messages: [...chat.messages, newMessage], lastMessage: messageInput, time: 'Now' }
        : chat
    ));
    
    setActiveChat((prev: any) => ({ ...prev, messages: [...prev.messages, newMessage] }));
    setMessageInput('');
  };

  const likePost = (postId: number) => {
    setPosts(prev => prev.map(post => 
      post.id === postId 
        ? { ...post, liked: !post.liked, likes: post.liked ? post.likes - 1 : post.likes + 1 }
        : post
    ));
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setCameraActive(true);
      }
    } catch (err) {
      alert('Camera access denied');
    }
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        canvasRef.current.width = videoRef.current.videoWidth;
        canvasRef.current.height = videoRef.current.videoHeight;
        context.drawImage(videoRef.current, 0, 0);
        
        const newPost = {
          id: Date.now(),
          user: userProfile.name,
          avatar: '📸',
          content: 'Just posted a new pic!',
          likes: 0,
          comments: 0,
          shares: 0,
          time: 'Now',
          liked: false
        };
        
        setPosts(prev => [newPost, ...prev]);
        setUserProfile((prev: any) => ({ ...prev, packsAvailable: prev.packsAvailable + 1, picCount: prev.picCount + 1 }));
        
        if (videoRef.current && videoRef.current.srcObject) {
          const stream = videoRef.current.srcObject as MediaStream;
          stream.getTracks().forEach(track => track.stop());
        }
        setCameraActive(false);
        setActiveTab('home');
        alert('Photo posted! You earned a pack!');
      }
    }
  };

  // F1 Racing Game Logic - Endless Runner Style
  const startRacing = () => {
    setRacingGame({
      playerLane: 1,
      score: 0,
      speed: 3,
      gameStarted: false,
      countdown: 3,
      gameOver: false,
      highScore: racingGame.highScore,
      obstacles: [],
      boosts: [],
      nitro: 0,
      nitroActive: false
    });
    
    let count = 3;
    const countdownInterval = setInterval(() => {
      count--;
      setRacingGame(prev => ({ ...prev, countdown: count }));
      if (count === 0) {
        clearInterval(countdownInterval);
        setRacingGame(prev => ({ ...prev, gameStarted: true }));
      }
    }, 1000);
  };

  useEffect(() => {
    if (activeGame === 'racing' && racingGame.gameStarted && !racingGame.gameOver) {
      const interval = setInterval(() => {
        setRacingGame(prev => {
          const currentSpeed = prev.nitroActive ? prev.speed * 1.5 : prev.speed;
          let newObstacles = prev.obstacles
            .map(o => ({ ...o, y: o.y + currentSpeed }))
            .filter(o => o.y < 110);
          
          let newBoosts = prev.boosts
            .map(b => ({ ...b, y: b.y + currentSpeed }))
            .filter(b => b.y < 110);
          
          if (Math.random() < 0.03 + prev.score / 5000) {
            const obstacleTypes: ('car' | 'cone' | 'oil')[] = ['car', 'cone', 'oil'];
            newObstacles.push({
              lane: Math.floor(Math.random() * 3),
              y: -10,
              type: obstacleTypes[Math.floor(Math.random() * obstacleTypes.length)]
            });
          }
          
          if (Math.random() < 0.01) {
            newBoosts.push({
              lane: Math.floor(Math.random() * 3),
              y: -10
            });
          }
          
          let newNitro = prev.nitro;
          let newNitroActive = prev.nitroActive;
          let collected = false;
          
          newBoosts = newBoosts.filter(b => {
            if (b.lane === prev.playerLane && b.y > 70 && b.y < 90) {
              newNitro = Math.min(100, newNitro + 25);
              collected = true;
              return false;
            }
            return true;
          });
          
          const collision = newObstacles.some(o => 
            o.lane === prev.playerLane && o.y > 70 && o.y < 90
          );
          
          if (collision) {
            const isHighScore = prev.score > prev.highScore;
            if (isHighScore) {
              setUserProfile((p: any) => ({ ...p, packsAvailable: p.packsAvailable + 1 }));
            }
            return {
              ...prev,
              gameOver: true,
              highScore: Math.max(prev.score, prev.highScore)
            };
          }
          
          if (newNitroActive && newNitro > 0) {
            newNitro = Math.max(0, newNitro - 1);
            if (newNitro === 0) newNitroActive = false;
          }
          
          return {
            ...prev,
            score: prev.score + 1,
            speed: Math.min(8, 3 + prev.score / 200),
            obstacles: newObstacles,
            boosts: newBoosts,
            nitro: newNitro,
            nitroActive: newNitroActive
          };
        });
      }, 50);
      return () => clearInterval(interval);
    }
  }, [activeGame, racingGame.gameStarted, racingGame.gameOver]);

  useEffect(() => {
    if (activeGame === 'racing' && racingGame.gameStarted && !racingGame.gameOver) {
      const handleKey = (e: KeyboardEvent) => {
        if (e.key === 'ArrowLeft') {
          setRacingGame(p => ({ ...p, playerLane: Math.max(0, p.playerLane - 1) }));
        }
        if (e.key === 'ArrowRight') {
          setRacingGame(p => ({ ...p, playerLane: Math.min(2, p.playerLane + 1) }));
        }
        if ((e.key === 'ArrowUp' || e.key === ' ') && racingGame.nitro > 0) {
          setRacingGame(p => ({ ...p, nitroActive: true }));
        }
      };
      window.addEventListener('keydown', handleKey);
      return () => window.removeEventListener('keydown', handleKey);
    }
  }, [activeGame, racingGame.gameStarted, racingGame.gameOver, racingGame.nitro]);

  // Memory Game Logic
  const initMemoryGame = () => {
    const emojis = ['🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼'];
    const gameCards = [...emojis, ...emojis]
      .sort(() => Math.random() - 0.5)
      .map((emoji, id) => ({ id, emoji, flipped: false, matched: false }));
    
    setMemoryGame({
      cards: gameCards,
      flipped: [],
      matched: [],
      moves: 0,
      gameOver: false,
      highScore: memoryGame.highScore
    });
  };

  const handleCardClick = (id: number) => {
    if (memoryGame.flipped.length === 2 || memoryGame.cards[id].flipped || memoryGame.cards[id].matched) return;
    
    const newCards = [...memoryGame.cards];
    newCards[id].flipped = true;
    
    const newFlipped = [...memoryGame.flipped, id];
    
    if (newFlipped.length === 2) {
      setMemoryGame((prev: any) => ({ ...prev, cards: newCards, flipped: newFlipped, moves: prev.moves + 1 }));
      
      if (newCards[newFlipped[0]].emoji === newCards[newFlipped[1]].emoji) {
        newCards[newFlipped[0]].matched = true;
        newCards[newFlipped[1]].matched = true;
        setMemoryGame((prev: any) => ({
          ...prev,
          cards: newCards,
          flipped: [],
          matched: [...prev.matched, newFlipped[0], newFlipped[1]]
        }));
        
        if (newCards.every((c: any) => c.matched)) {
          if (memoryGame.moves + 1 < (memoryGame.highScore || Infinity)) {
             setUserProfile((p: any) => ({ ...p, packsAvailable: p.packsAvailable + 1 }));
             alert('New record! You earned a pack!');
          }
          setMemoryGame((prev: any) => ({ ...prev, gameOver: true, highScore: prev.moves + 1 }));
        }
      } else {
        setTimeout(() => {
          newCards[newFlipped[0]].flipped = false;
          newCards[newFlipped[1]].flipped = false;
          setMemoryGame((prev: any) => ({ ...prev, cards: newCards, flipped: [] }));
        }, 1000);
      }
    } else {
      setMemoryGame((prev: any) => ({ ...prev, cards: newCards, flipped: newFlipped }));
    }
  };

  // F1 Reaction Game Logic (5 lights)
  const startReactionGame = () => {
    setReactionGame({
      phase: 'countdown',
      lightsOn: 0,
      startTime: 0,
      reactionTime: 0,
      bestTime: reactionGame.bestTime
    });
    
    let lightCount = 0;
    const lightInterval = setInterval(() => {
      lightCount++;
      setReactionGame(prev => ({ ...prev, lightsOn: lightCount }));
      if (lightCount === 5) {
        clearInterval(lightInterval);
        const delay = 1000 + Math.random() * 3000;
        setTimeout(() => {
          setReactionGame(prev => ({ ...prev, phase: 'go', startTime: Date.now() }));
        }, delay);
      }
    }, 800);
  };

  const handleReactionClick = () => {
    if (reactionGame.phase === 'go') {
      const time = Date.now() - reactionGame.startTime;
      if (time < reactionGame.bestTime) {
         setUserProfile((p: any) => ({ ...p, packsAvailable: p.packsAvailable + 1 }));
      }
      setReactionGame(prev => ({
        ...prev,
        phase: 'result',
        reactionTime: time,
        bestTime: Math.min(time, prev.bestTime)
      }));
    } else if (reactionGame.phase === 'countdown') {
      setReactionGame(prev => ({ ...prev, phase: 'tooEarly' }));
    }
  };

  // Sequence Game Logic
  const startSequenceGame = () => {
    setSequenceGame({
      sequence: [],
      userSequence: [],
      level: 1,
      showing: false,
      gameOver: false,
      highScore: sequenceGame.highScore
    });
    nextLevel([]);
  };

  const nextLevel = (currentSequence: number[]) => {
    const nextNum = Math.floor(Math.random() * 9) + 1;
    const newSequence = [...currentSequence, nextNum];
    setSequenceGame((prev: any) => ({ ...prev, sequence: newSequence, userSequence: [], showing: true }));
    
    let i = 0;
    const interval = setInterval(() => {
      // Show number (logic handled in render via visual feedback could be complex, simplified here)
      // We'll just show the sequence in a text for now or flash buttons
      i++;
      if (i >= newSequence.length) {
        clearInterval(interval);
        setSequenceGame((prev: any) => ({ ...prev, showing: false }));
      }
    }, 1000);
  };
  
  // Simplified Sequence Logic for UI: Just show numbers one by one
  useEffect(() => {
     if (activeGame === 'sequence' && sequenceGame.showing) {
        // Logic to flash numbers would go here, but for simplicity let's just display current sequence
     }
  }, [activeGame, sequenceGame.showing]);

  const handleSequenceInput = (num: number) => {
    if (sequenceGame.showing || sequenceGame.gameOver) return;
    
    const newUserSequence = [...sequenceGame.userSequence, num];
    setSequenceGame((prev: any) => ({ ...prev, userSequence: newUserSequence }));
    
    if (newUserSequence[newUserSequence.length - 1] !== sequenceGame.sequence[newUserSequence.length - 1]) {
       setSequenceGame((prev: any) => ({ ...prev, gameOver: true, highScore: Math.max(prev.level - 1, prev.highScore) }));
       return;
    }
    
    if (newUserSequence.length === sequenceGame.sequence.length) {
       if (sequenceGame.level > sequenceGame.highScore) {
         // Check if significant milestone
       }
       setTimeout(() => {
         setSequenceGame((prev: any) => ({ ...prev, level: prev.level + 1 }));
         nextLevel(sequenceGame.sequence);
       }, 500);
    }
  };

  // Block Blast Game Logic
  const blockPieces = [
    { shape: [[1]], color: 1 },
    { shape: [[1, 1]], color: 2 },
    { shape: [[1], [1]], color: 2 },
    { shape: [[1, 1, 1]], color: 3 },
    { shape: [[1], [1], [1]], color: 3 },
    { shape: [[1, 1], [1, 1]], color: 4 },
    { shape: [[1, 1, 1], [1, 0, 0]], color: 5 },
    { shape: [[1, 0], [1, 0], [1, 1]], color: 5 },
    { shape: [[1, 1, 1], [0, 0, 1]], color: 6 },
    { shape: [[1, 1], [1, 0]], color: 6 },
    { shape: [[0, 1], [1, 1], [1, 0]], color: 7 },
    { shape: [[1, 0], [1, 1], [0, 1]], color: 7 },
    { shape: [[1, 1, 1, 1]], color: 8 },
    { shape: [[1], [1], [1], [1]], color: 8 },
    { shape: [[1, 1, 1], [0, 1, 0]], color: 9 },
  ];

  const blockColors = [
    'bg-gray-800',
    'bg-red-500', 'bg-blue-500', 'bg-green-500', 'bg-yellow-500',
    'bg-purple-500', 'bg-pink-500', 'bg-orange-500', 'bg-cyan-500', 'bg-indigo-500'
  ];

  const startBlockGame = () => {
    setBlockGame({
      grid: Array(8).fill(null).map(() => Array(8).fill(0)),
      score: 0,
      highScore: blockGame.highScore,
      gameOver: false,
      currentPieces: getRandomPieces(),
      selectedPiece: null,
      draggingPiece: null,
      ghostPosition: null,
      clearingCells: []
    });
  };

  const getRandomPieces = () => {
    const pieces = [];
    for (let i = 0; i < 3; i++) {
      pieces.push(blockPieces[Math.floor(Math.random() * blockPieces.length)]);
    }
    return pieces;
  };

  const canPlacePiece = (grid: number[][], piece: number[][], row: number, col: number) => {
    for (let r = 0; r < piece.length; r++) {
      for (let c = 0; c < piece[r].length; c++) {
        if (piece[r][c] === 1) {
          const newRow = row + r;
          const newCol = col + c;
          if (newRow < 0 || newRow >= 8 || newCol < 0 || newCol >= 8) return false;
          if (grid[newRow][newCol] !== 0) return false;
        }
      }
    }
    return true;
  };

  const handleBlockDragStart = (pieceIdx: number) => {
    if (blockGame.gameOver || !blockGame.currentPieces[pieceIdx]) return;
    setBlockGame(prev => ({ ...prev, draggingPiece: pieceIdx, selectedPiece: pieceIdx }));
  };

  const handleBlockDragOver = (row: number, col: number) => {
    if (blockGame.draggingPiece === null) return;
    const piece = blockGame.currentPieces[blockGame.draggingPiece];
    if (!piece) return;
    
    const canPlace = canPlacePiece(blockGame.grid, piece.shape, row, col);
    setBlockGame(prev => ({ 
      ...prev, 
      ghostPosition: canPlace ? { row, col } : null 
    }));
  };

  const handleBlockDrop = (row: number, col: number) => {
    if (blockGame.draggingPiece === null || blockGame.gameOver) {
      setBlockGame(prev => ({ ...prev, draggingPiece: null, ghostPosition: null }));
      return;
    }
    
    const pieceIdx = blockGame.draggingPiece;
    const piece = blockGame.currentPieces[pieceIdx];
    if (!piece || !canPlacePiece(blockGame.grid, piece.shape, row, col)) {
      setBlockGame(prev => ({ ...prev, draggingPiece: null, ghostPosition: null }));
      return;
    }
    
    const newGrid = blockGame.grid.map(r => [...r]);
    for (let r = 0; r < piece.shape.length; r++) {
      for (let c = 0; c < piece.shape[r].length; c++) {
        if (piece.shape[r][c] === 1) {
          newGrid[row + r][col + c] = piece.color;
        }
      }
    }
    
    // Check for completed rows and columns
    const rowsToClear: number[] = [];
    const colsToClear: number[] = [];
    
    for (let r = 0; r < 8; r++) {
      if (newGrid[r].every(cell => cell !== 0)) rowsToClear.push(r);
    }
    for (let c = 0; c < 8; c++) {
      if (newGrid.every(rowData => rowData[c] !== 0)) colsToClear.push(c);
    }
    
    // Collect cells to clear for animation
    const cellsToClear: {row: number, col: number}[] = [];
    rowsToClear.forEach(r => {
      for (let c = 0; c < 8; c++) cellsToClear.push({ row: r, col: c });
    });
    colsToClear.forEach(c => {
      for (let r = 0; r < 8; r++) {
        if (!cellsToClear.some(cell => cell.row === r && cell.col === c)) {
          cellsToClear.push({ row: r, col: c });
        }
      }
    });
    
    const newPieces = [...blockGame.currentPieces];
    newPieces[pieceIdx] = null as any;
    
    const allUsed = newPieces.every(p => p === null);
    const finalPieces = allUsed ? getRandomPieces() : newPieces;
    
    const pieceScore = piece.shape.flat().filter(v => v === 1).length * 10;
    const lineScore = (rowsToClear.length + colsToClear.length) * 100;
    const newScore = blockGame.score + pieceScore + lineScore;
    
    if (cellsToClear.length > 0) {
      // Show clearing animation first
      setBlockGame(prev => ({
        ...prev,
        grid: newGrid,
        score: newScore,
        highScore: Math.max(newScore, prev.highScore),
        currentPieces: finalPieces,
        selectedPiece: null,
        draggingPiece: null,
        ghostPosition: null,
        clearingCells: cellsToClear
      }));
      
      // After animation, clear the cells
      setTimeout(() => {
        setBlockGame(prev => {
          const clearedGrid = prev.grid.map(r => [...r]);
          prev.clearingCells.forEach(cell => {
            clearedGrid[cell.row][cell.col] = 0;
          });
          
          // Check game over
          const canPlaceAny = prev.currentPieces.some(p => {
            if (!p) return false;
            for (let r = 0; r < 8; r++) {
              for (let c = 0; c < 8; c++) {
                if (canPlacePiece(clearedGrid, p.shape, r, c)) return true;
              }
            }
            return false;
          });
          
          if (!canPlaceAny && prev.score > prev.highScore) {
            setUserProfile((p: any) => ({ ...p, packsAvailable: p.packsAvailable + 1 }));
          }
          
          return {
            ...prev,
            grid: clearedGrid,
            clearingCells: [],
            gameOver: !canPlaceAny
          };
        });
      }, 400);
    } else {
      // No lines to clear, check game over immediately
      const canPlaceAny = finalPieces.some(p => {
        if (!p) return false;
        for (let r = 0; r < 8; r++) {
          for (let c = 0; c < 8; c++) {
            if (canPlacePiece(newGrid, p.shape, r, c)) return true;
          }
        }
        return false;
      });
      
      if (!canPlaceAny && newScore > blockGame.highScore) {
        setUserProfile((p: any) => ({ ...p, packsAvailable: p.packsAvailable + 1 }));
      }
      
      setBlockGame(prev => ({
        ...prev,
        grid: newGrid,
        score: newScore,
        highScore: Math.max(newScore, prev.highScore),
        currentPieces: finalPieces,
        selectedPiece: null,
        draggingPiece: null,
        ghostPosition: null,
        gameOver: !canPlaceAny
      }));
    }
  };

  const handleBlockDragEnd = () => {
    setBlockGame(prev => ({ ...prev, draggingPiece: null, ghostPosition: null }));
  };

  // Keep old placePiece for click fallback
  const placePiece = (row: number, col: number) => {
    if (blockGame.selectedPiece === null || blockGame.gameOver) return;
    handleBlockDrop(row, col);
  };

  const renderContent = () => {
    if (showPackAnimation) {
      return (
        <div className="fixed inset-0 bg-black/90 z-50 flex flex-col items-center justify-center p-4">
          <div className="animate-[spin_1s_linear_infinite] mb-8">
             <Sparkles className="w-16 h-16 text-yellow-400" />
          </div>
          {newCard && (
            <div className={`
              w-64 h-96 rounded-xl p-6 flex flex-col items-center justify-between 
              animate-[zoomIn_0.5s_ease-out]
              ${newCard.rarity === 'oneInMillion' ? 'bg-gradient-to-br from-black via-purple-900 to-gold border-4 border-yellow-400 shadow-[0_0_50px_rgba(255,215,0,0.5)]' :
                newCard.rarity === 'iconic' ? 'bg-gradient-to-br from-red-600 to-orange-600 border-4 border-red-300' :
                newCard.rarity === 'legendary' ? 'bg-gradient-to-br from-purple-600 to-blue-600 border-4 border-purple-300' :
                newCard.rarity === 'epic' ? 'bg-gradient-to-br from-blue-500 to-cyan-400 border-4 border-blue-200' :
                newCard.rarity === 'rare' ? 'bg-gradient-to-br from-green-500 to-emerald-400 border-4 border-green-200' :
                'bg-white text-black border-4 border-gray-200'}
            `}>
              <div className="text-lg font-bold text-white/80 uppercase tracking-widest">{newCard.rarity}</div>
              <div className="text-8xl animate-[bounce_2s_infinite]">{newCard.image}</div>
              <div className={`text-2xl font-bold text-center ${newCard.rarity === 'common' ? 'text-gray-900' : 'text-white'}`}>{newCard.name}</div>
              <div className="flex gap-2">
                {Array(5).fill(0).map((_, i) => (
                   <Heart key={i} className={`w-4 h-4 ${i < (
                     newCard.rarity === 'oneInMillion' ? 5 :
                     newCard.rarity === 'iconic' ? 4 :
                     newCard.rarity === 'legendary' ? 3 :
                     newCard.rarity === 'epic' ? 2 : 1
                   ) ? 'fill-yellow-400 text-yellow-400' : 'text-gray-400'}`} />
                ))}
              </div>
            </div>
          )}
        </div>
      );
    }

    if (cameraActive) {
      return (
        <div className="fixed inset-0 bg-black z-50 flex flex-col">
          <div className="flex justify-between p-4 text-white">
            <X className="w-8 h-8" onClick={() => {
              if (videoRef.current && videoRef.current.srcObject) {
                const stream = videoRef.current.srcObject as MediaStream;
                stream.getTracks().forEach(t => t.stop());
              }
              setCameraActive(false);
            }} />
            <div className="font-bold">Camera</div>
            <div className="w-8" />
          </div>
          <div className="flex-1 relative bg-gray-900">
            <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
            <canvas ref={canvasRef} className="hidden" />
          </div>
          <div className="p-8 flex justify-center bg-black">
            <button 
              onClick={capturePhoto}
              className="w-20 h-20 rounded-full border-4 border-white flex items-center justify-center"
            >
              <div className="w-16 h-16 rounded-full bg-white" />
            </button>
          </div>
        </div>
      );
    }

    if (activeTab === 'home') {
      return (
        <div className="pb-24 bg-black min-h-full">
          {/* Feed/Reels Toggle */}
          <div className="sticky top-0 z-20 bg-black/90 backdrop-blur-sm border-b border-gray-800">
            <div className="flex">
              <button
                onClick={() => setFeedMode('posts')}
                className={`flex-1 py-3 text-center font-bold text-sm transition ${feedMode === 'posts' ? 'text-white border-b-2 border-white' : 'text-gray-500'}`}
              >
                Posts
              </button>
              <button
                onClick={() => setFeedMode('reels')}
                className={`flex-1 py-3 text-center font-bold text-sm transition ${feedMode === 'reels' ? 'text-white border-b-2 border-white' : 'text-gray-500'}`}
              >
                Reels
              </button>
            </div>
          </div>

          {feedMode === 'posts' ? (
            <div className="bg-white">
              {/* Stories */}
              <div className="flex gap-4 overflow-x-auto py-4 px-4 scrollbar-hide bg-white border-b border-gray-100">
                <div className="flex-shrink-0 flex flex-col items-center gap-1">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-tr from-yellow-400 to-fuchsia-600 p-0.5">
                    <div className="w-full h-full rounded-full bg-white border-2 border-white flex items-center justify-center">
                      <Plus className="w-6 h-6 text-gray-400" />
                    </div>
                  </div>
                  <span className="text-xs font-medium">Your Story</span>
                </div>
                {storyUsers.map((user, i) => (
                  <div key={i} className="flex-shrink-0 flex flex-col items-center gap-1">
                    <div className={`w-16 h-16 rounded-full p-0.5 ${user.hasStory ? 'bg-gradient-to-tr from-yellow-400 via-red-500 to-fuchsia-600' : 'bg-gray-300'}`}>
                      <div className="w-full h-full rounded-full bg-white border-2 border-white overflow-hidden flex items-center justify-center text-2xl">
                        {user.avatar}
                      </div>
                    </div>
                    <span className="text-xs font-medium truncate w-16 text-center">{user.name}</span>
                  </div>
                ))}
              </div>

              {/* Pack Opening CTA */}
              <div className="m-4 p-5 bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl text-white shadow-lg relative overflow-hidden">
                <div className="relative z-10">
                  <h3 className="text-xl font-bold mb-1">Daily Pack Ready!</h3>
                  <p className="text-sm mb-3 opacity-90">Open to collect rare cards</p>
                  <button 
                    onClick={openPack}
                    className="bg-white text-purple-600 px-5 py-2 rounded-full font-bold text-sm shadow-md hover:bg-gray-100 transition"
                    disabled={userProfile.packsAvailable === 0}
                  >
                    {userProfile.packsAvailable > 0 ? `Open Pack (${userProfile.packsAvailable})` : 'Next in 24h'}
                  </button>
                </div>
                <Sparkles className="absolute -top-4 -right-4 w-24 h-24 text-white/20" />
              </div>

              {/* Posts Feed */}
              <div className="space-y-0">
                {feedPosts.map(post => (
                  <div key={post.id} className="bg-white border-b border-gray-100">
                    {/* Post Header */}
                    <div className="flex items-center justify-between px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-yellow-400 to-fuchsia-600 p-0.5">
                          <div className="w-full h-full rounded-full bg-white flex items-center justify-center text-lg">
                            {post.avatar}
                          </div>
                        </div>
                        <div>
                          <div className="font-semibold text-sm">{post.user}</div>
                          {post.location && <div className="text-xs text-gray-500">{post.location}</div>}
                        </div>
                      </div>
                      <button className="text-gray-600 text-xl">•••</button>
                    </div>
                    
                    {/* Post Image */}
                    <div className="aspect-square bg-gradient-to-br from-gray-100 to-gray-200 flex items-center justify-center">
                      <span className="text-8xl">{post.image}</span>
                    </div>
                    
                    {/* Post Actions */}
                    <div className="px-4 py-3">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-4">
                          <button 
                            onClick={() => likeFeedPost(post.id)} 
                            className={`transition-transform active:scale-125 ${post.liked ? 'text-red-500' : 'text-gray-800'}`}
                          >
                            <Heart className={`w-7 h-7 ${post.liked ? 'fill-current' : ''}`} />
                          </button>
                          <button className="text-gray-800">
                            <MessageCircle className="w-7 h-7" />
                          </button>
                          <button className="text-gray-800">
                            <Send className="w-6 h-6 -rotate-45" />
                          </button>
                        </div>
                        <button className="text-gray-800">
                          <Bookmark className="w-7 h-7" />
                        </button>
                      </div>
                      <div className="font-semibold text-sm mb-1">{post.likes.toLocaleString()} likes</div>
                      <div className="text-sm">
                        <span className="font-semibold">{post.user}</span>{' '}
                        <span className="text-gray-800">{post.caption}</span>
                      </div>
                      {post.comments > 0 && (
                        <button className="text-gray-500 text-sm mt-1">View all {post.comments} comments</button>
                      )}
                      <div className="text-xs text-gray-400 mt-2 uppercase">{post.time}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            /* Reels View */
            <div className="snap-y snap-mandatory h-[calc(100vh-8rem)] overflow-y-auto scrollbar-hide">
              {reels.map((reel, index) => (
                <div 
                  key={reel.id} 
                  className="snap-start h-[calc(100vh-8rem)] relative bg-gradient-to-b from-gray-900 to-black flex items-center justify-center"
                >
                  {/* Reel Background */}
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-[200px] opacity-30">{reel.image}</span>
                  </div>
                  
                  {/* Reel Content Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-black/30" />
                  
                  {/* Right Side Actions */}
                  <div className="absolute right-3 bottom-32 flex flex-col items-center gap-5">
                    <button 
                      onClick={() => likeReel(reel.id)}
                      className="flex flex-col items-center"
                    >
                      <Heart className={`w-8 h-8 ${reel.liked ? 'fill-red-500 text-red-500' : 'text-white'}`} />
                      <span className="text-white text-xs mt-1">{formatNumber(reel.likes)}</span>
                    </button>
                    <button className="flex flex-col items-center">
                      <MessageCircle className="w-8 h-8 text-white" />
                      <span className="text-white text-xs mt-1">{formatNumber(reel.comments)}</span>
                    </button>
                    <button className="flex flex-col items-center">
                      <Send className="w-7 h-7 text-white -rotate-45" />
                      <span className="text-white text-xs mt-1">Share</span>
                    </button>
                    <button className="flex flex-col items-center">
                      <Bookmark className="w-7 h-7 text-white" />
                    </button>
                  </div>
                  
                  {/* Bottom Info */}
                  <div className="absolute bottom-6 left-4 right-16">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-yellow-400 to-fuchsia-600 p-0.5">
                        <div className="w-full h-full rounded-full bg-black flex items-center justify-center text-lg">
                          {reel.avatar}
                        </div>
                      </div>
                      <span className="text-white font-semibold">{reel.user}</span>
                      <button className="px-4 py-1 border border-white rounded-lg text-white text-sm font-semibold">
                        Follow
                      </button>
                    </div>
                    <p className="text-white text-sm mb-2">{reel.caption}</p>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 rounded bg-white/20 flex items-center justify-center">
                        <Play className="w-2 h-2 text-white fill-white" />
                      </div>
                      <span className="text-white text-xs">{reel.music}</span>
                    </div>
                  </div>
                  
                  {/* Progress indicator */}
                  <div className="absolute top-4 left-4 right-4">
                    <div className="text-white text-xs opacity-60">Reel {index + 1}</div>
                  </div>
                </div>
              ))}
              
              {/* Load More Trigger */}
              <div className="h-20 flex items-center justify-center">
                <button 
                  onClick={loadMoreReels}
                  className="text-white text-sm opacity-60"
                >
                  Loading more...
                </button>
              </div>
            </div>
          )}
        </div>
      );
    }

    if (activeTab === 'games') {
      if (activeGame) {
        return (
          <div className="h-full flex flex-col bg-gray-900 text-white p-4">
            <div className="flex items-center justify-between mb-4">
              <button onClick={() => setActiveGame(null)} className="p-2 bg-gray-800 rounded-full hover:bg-gray-700 transition">
                <ArrowLeft className="w-6 h-6" />
              </button>
              <h2 className="text-xl font-bold capitalize">{activeGame}</h2>
              <div className="w-10" />
            </div>

            <div className="flex-1 flex flex-col items-center justify-center w-full max-w-md mx-auto">
              {activeGame === 'racing' && (
                <div className="w-full flex flex-col items-center overflow-hidden">
                  {/* HUD Header */}
                  <div className="w-full max-w-xs mb-3 px-2">
                    <div className="flex justify-between items-center bg-gradient-to-r from-red-900/80 to-red-800/80 rounded-xl p-3 border border-red-500/40 shadow-lg">
                      <div className="text-center">
                        <div className="text-[10px] text-red-300 font-bold tracking-wider">SCORE</div>
                        <div className="text-2xl font-black text-white tabular-nums">{racingGame.score}</div>
                      </div>
                      <div className="text-center flex flex-col items-center">
                        <div className="text-[10px] text-yellow-300 font-bold tracking-wider">SPEED</div>
                        <div className="text-lg font-bold text-yellow-400">{Math.round(racingGame.speed * 30)} km/h</div>
                      </div>
                      <div className="text-center">
                        <div className="text-[10px] text-red-300 font-bold tracking-wider">BEST</div>
                        <div className="text-xl font-bold text-red-300">{racingGame.highScore}</div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Nitro Bar */}
                  <div className="w-full max-w-xs mb-2 px-2">
                    <div className="bg-gray-800/80 rounded-lg p-2 border border-gray-600/50">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-bold text-cyan-400">⚡ NITRO</span>
                        <span className="text-[10px] text-gray-500">TAP TO BOOST</span>
                      </div>
                      <div className="w-full h-2.5 bg-gray-700 rounded-full overflow-hidden shadow-inner">
                        <div 
                          className={`h-full transition-all duration-100 rounded-full ${
                            racingGame.nitroActive 
                              ? 'bg-gradient-to-r from-yellow-400 via-orange-400 to-red-400 animate-pulse shadow-[0_0_10px_rgba(250,204,21,0.8)]' 
                              : 'bg-gradient-to-r from-cyan-400 to-blue-500'
                          }`}
                          style={{ width: `${racingGame.nitro}%` }}
                        />
                      </div>
                    </div>
                  </div>
                  
                  {/* Game Track - Taller aspect ratio */}
                  <div className="relative w-full max-w-xs aspect-[3/5] bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900 rounded-2xl overflow-hidden border-2 border-gray-600 shadow-2xl">
                    {/* Track background with perspective effect */}
                    <div className="absolute inset-0">
                      {/* Grass/barrier edges */}
                      <div className="absolute inset-y-0 left-0 w-4 bg-gradient-to-r from-green-800 to-green-900" />
                      <div className="absolute inset-y-0 right-0 w-4 bg-gradient-to-l from-green-800 to-green-900" />
                      
                      {/* Asphalt road */}
                      <div className="absolute inset-y-0 left-4 right-4 bg-gradient-to-b from-gray-700 via-gray-600 to-gray-700" />
                      
                      {/* Red/white curbs on edges */}
                      <div className="absolute inset-y-0 left-4 w-2 flex flex-col">
                        {Array.from({length: 20}).map((_, i) => (
                          <div key={i} className={`flex-1 ${i % 2 === 0 ? 'bg-red-600' : 'bg-white'}`} />
                        ))}
                      </div>
                      <div className="absolute inset-y-0 right-4 w-2 flex flex-col">
                        {Array.from({length: 20}).map((_, i) => (
                          <div key={i} className={`flex-1 ${i % 2 === 0 ? 'bg-red-600' : 'bg-white'}`} />
                        ))}
                      </div>
                      
                      {/* Lane dividers */}
                      <div className="absolute inset-y-0 left-1/3 w-1 flex flex-col gap-4">
                        {Array.from({length: 12}).map((_, i) => (
                          <div 
                            key={i} 
                            className="h-6 bg-white/70 rounded-full"
                            style={{ transform: `translateY(${(racingGame.score * 4) % 80}px)` }}
                          />
                        ))}
                      </div>
                      <div className="absolute inset-y-0 right-1/3 w-1 flex flex-col gap-4">
                        {Array.from({length: 12}).map((_, i) => (
                          <div 
                            key={i} 
                            className="h-6 bg-white/70 rounded-full"
                            style={{ transform: `translateY(${(racingGame.score * 4) % 80}px)` }}
                          />
                        ))}
                      </div>
                    </div>
                    
                    {/* Speed lines effect when nitro active */}
                    {racingGame.nitroActive && (
                      <div className="absolute inset-0 pointer-events-none">
                        {[...Array(6)].map((_, i) => (
                          <div 
                            key={i}
                            className="absolute h-20 w-0.5 bg-gradient-to-b from-yellow-400/0 via-yellow-400/60 to-yellow-400/0 animate-pulse"
                            style={{ 
                              left: `${15 + i * 14}%`,
                              top: `${-20 + (racingGame.score * 8 + i * 20) % 120}%`
                            }}
                          />
                        ))}
                      </div>
                    )}
                    
                    {/* Obstacles with shadows */}
                    {racingGame.obstacles.map((obs, i) => (
                      <div 
                        key={i}
                        className="absolute transition-all duration-50"
                        style={{ 
                          left: `${(obs.lane * 30) + 20}%`,
                          top: `${obs.y}%`,
                          transform: 'translateX(-50%)'
                        }}
                      >
                        <div className="relative">
                          <div className="absolute inset-0 blur-sm bg-black/30 translate-y-1 scale-90" />
                          <span className="text-3xl drop-shadow-lg relative">
                            {obs.type === 'car' ? '🚗' : obs.type === 'cone' ? '🚧' : '🛢️'}
                          </span>
                        </div>
                      </div>
                    ))}
                    
                    {/* Boosts with glow effect */}
                    {racingGame.boosts.map((boost, i) => (
                      <div 
                        key={i}
                        className="absolute transition-all duration-50"
                        style={{ 
                          left: `${(boost.lane * 30) + 20}%`,
                          top: `${boost.y}%`,
                          transform: 'translateX(-50%)'
                        }}
                      >
                        <div className="relative animate-bounce">
                          <div className="absolute inset-0 w-8 h-8 bg-cyan-400/50 rounded-full blur-md -translate-x-1 -translate-y-1" />
                          <span className="text-2xl drop-shadow-[0_0_8px_rgba(34,211,238,0.8)]">⚡</span>
                        </div>
                      </div>
                    ))}
                    
                    {/* Player Car with effects */}
                    <div 
                      className={`absolute bottom-[15%] transition-all duration-75 ${racingGame.nitroActive ? 'scale-125' : 'scale-110'}`}
                      style={{ 
                        left: `${(racingGame.playerLane * 30) + 20}%`,
                        transform: 'translateX(-50%)'
                      }}
                    >
                      {/* Car shadow */}
                      <div className="absolute top-1 left-1 text-4xl opacity-30 blur-sm">🏎️</div>
                      {/* Car */}
                      <span className="text-4xl drop-shadow-xl relative z-10">🏎️</span>
                      {/* Nitro flame effect */}
                      {racingGame.nitroActive && (
                        <>
                          <div className="absolute -bottom-4 left-1/2 -translate-x-1/2 text-2xl animate-pulse">🔥</div>
                          <div className="absolute -bottom-6 left-1/2 -translate-x-1/2 w-8 h-12 bg-gradient-to-t from-orange-500/0 via-orange-500/40 to-yellow-400/60 blur-sm rounded-full" />
                        </>
                      )}
                    </div>
                    
                    {/* Countdown with F1 style */}
                    {!racingGame.gameStarted && racingGame.countdown > 0 && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black/70 backdrop-blur-sm">
                        <div className="text-center">
                          <span className="text-9xl font-black text-red-500 drop-shadow-[0_0_30px_rgba(239,68,68,0.8)] animate-pulse">{racingGame.countdown}</span>
                          <p className="text-white/60 mt-4 text-sm tracking-widest">GET READY</p>
                        </div>
                      </div>
                    )}
                    
                    {/* Game Over overlay */}
                    {racingGame.gameOver && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/85 backdrop-blur-sm">
                        <div className="text-6xl mb-2 animate-bounce">💥</div>
                        <h3 className="text-3xl font-black text-red-500 tracking-wider">CRASH!</h3>
                        <p className="text-4xl font-bold text-white mt-4">{racingGame.score}</p>
                        <p className="text-sm text-gray-400 mb-4">FINAL SCORE</p>
                        {racingGame.score >= racingGame.highScore && racingGame.score > 0 && (
                          <div className="bg-yellow-500/20 border border-yellow-500/50 rounded-full px-4 py-1 mb-4">
                            <p className="text-yellow-400 font-bold text-sm">🏆 NEW HIGH SCORE!</p>
                          </div>
                        )}
                        <button 
                          onClick={startRacing}
                          className="px-8 py-3 bg-gradient-to-r from-red-600 to-red-500 rounded-full font-bold flex items-center gap-2 shadow-lg hover:from-red-500 hover:to-red-400 transition-all"
                        >
                          <RefreshCw className="w-5 h-5" /> RACE AGAIN
                        </button>
                      </div>
                    )}
                  </div>
                  
                  {/* Controls - Modern design */}
                  <div className="mt-4 flex flex-col items-center gap-3 w-full max-w-xs">
                    <button 
                      className={`w-full py-4 rounded-2xl text-lg font-bold transition-all shadow-xl ${
                        racingGame.nitro > 0 
                          ? 'bg-gradient-to-r from-yellow-500 via-orange-500 to-yellow-500 active:scale-95 shadow-yellow-500/30' 
                          : 'bg-gray-700 text-gray-500 cursor-not-allowed'
                      }`}
                      onClick={() => racingGame.nitro > 0 && setRacingGame(p => ({ ...p, nitroActive: true }))}
                    >
                      ⚡ NITRO BOOST
                    </button>
                    <div className="flex gap-4 w-full">
                      <button 
                        className="flex-1 py-5 bg-gradient-to-b from-gray-700 to-gray-800 rounded-2xl active:from-gray-600 active:to-gray-700 active:scale-95 transition-all border border-gray-600 shadow-lg flex items-center justify-center"
                        onClick={() => setRacingGame(p => ({ ...p, playerLane: Math.max(0, p.playerLane - 1) }))}
                      >
                        <ArrowLeft className="w-10 h-10" />
                      </button>
                      <button 
                        className="flex-1 py-5 bg-gradient-to-b from-gray-700 to-gray-800 rounded-2xl active:from-gray-600 active:to-gray-700 active:scale-95 transition-all border border-gray-600 shadow-lg flex items-center justify-center"
                        onClick={() => setRacingGame(p => ({ ...p, playerLane: Math.min(2, p.playerLane + 1) }))}
                      >
                        <ArrowRight className="w-10 h-10" />
                      </button>
                    </div>
                    <p className="text-[11px] text-gray-500 mt-1">🕹️ Use arrow keys or tap to steer • Collect ⚡ for nitro boost!</p>
                  </div>
                </div>
              )}

              {activeGame === 'memory' && (
                <>
                  <div className="mb-4 flex justify-between w-full max-w-sm px-4">
                    <span>Moves: {memoryGame.moves}</span>
                    <span>Best: {memoryGame.highScore || '-'}</span>
                  </div>
                  <div className="grid grid-cols-4 gap-3 p-4">
                    {memoryGame.cards.map((card: any, i: number) => (
                      <button
                        key={i}
                        onClick={() => handleCardClick(i)}
                        className={`
                          w-16 h-16 rounded-xl text-3xl flex items-center justify-center transition-all duration-300
                          ${card.flipped || card.matched ? 'bg-white rotate-0' : 'bg-blue-600 rotate-180 text-transparent'}
                        `}
                      >
                        {card.flipped || card.matched ? card.emoji : '?'}
                      </button>
                    ))}
                  </div>
                  {!memoryGame.cards.length && (
                    <button onClick={initMemoryGame} className="px-6 py-3 bg-blue-500 rounded-full font-bold mt-8">Start Game</button>
                  )}
                </>
              )}

              {activeGame === 'reaction' && (
                <div className="w-full flex flex-col items-center">
                  <h3 className="text-2xl font-bold mb-6 text-red-400">F1 Lights Out!</h3>
                  
                  {/* F1 Lights Panel */}
                  <div className="bg-gray-800 rounded-2xl p-6 mb-8">
                    <div className="flex gap-3">
                      {[1, 2, 3, 4, 5].map(light => (
                        <div 
                          key={light}
                          className={`w-12 h-12 rounded-full border-4 border-gray-600 transition-all duration-200 ${
                            reactionGame.phase === 'go' 
                              ? 'bg-gray-700' 
                              : reactionGame.lightsOn >= light 
                                ? 'bg-red-500 shadow-[0_0_20px_rgba(239,68,68,0.8)]' 
                                : 'bg-gray-700'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                  
                  {/* Click area */}
                  <div 
                    className={`w-full h-48 flex flex-col items-center justify-center rounded-2xl cursor-pointer transition-colors ${
                      reactionGame.phase === 'go' ? 'bg-green-500' : 
                      reactionGame.phase === 'countdown' ? 'bg-red-900' : 
                      reactionGame.phase === 'tooEarly' ? 'bg-yellow-600' :
                      'bg-gray-700'
                    }`}
                    onMouseDown={handleReactionClick}
                    onTouchStart={handleReactionClick}
                  >
                    {reactionGame.phase === 'idle' && (
                      <div className="text-center">
                        <div className="text-2xl font-bold mb-2">Ready to race?</div>
                        <div className="text-sm opacity-70">Tap to start</div>
                      </div>
                    )}
                    {reactionGame.phase === 'countdown' && (
                      <div className="text-2xl font-bold">Wait for lights out...</div>
                    )}
                    {reactionGame.phase === 'go' && (
                      <div className="text-4xl font-bold animate-pulse">GO! GO! GO!</div>
                    )}
                    {reactionGame.phase === 'tooEarly' && (
                      <div className="text-center">
                        <div className="text-3xl font-bold mb-2">⚠️ JUMP START!</div>
                        <div className="text-lg">Tap to try again</div>
                      </div>
                    )}
                    {reactionGame.phase === 'result' && (
                      <div className="text-center">
                        <div className="text-6xl font-bold mb-2">{reactionGame.reactionTime}ms</div>
                        <div className="text-sm opacity-70">
                          {reactionGame.reactionTime < 200 ? '🏆 Incredible!' : 
                           reactionGame.reactionTime < 300 ? '🔥 Great reaction!' : 
                           reactionGame.reactionTime < 400 ? '👍 Good!' : 'Keep practicing!'}
                        </div>
                        <div className="text-xs mt-2 opacity-50">Tap to try again</div>
                      </div>
                    )}
                  </div>
                  
                  {/* Best time */}
                  <div className="mt-6 text-center">
                    <span className="text-gray-400">Best Time: </span>
                    <span className="font-bold text-green-400">
                      {reactionGame.bestTime === Infinity ? '-' : reactionGame.bestTime + 'ms'}
                    </span>
                  </div>
                  
                  {(reactionGame.phase === 'idle' || reactionGame.phase === 'result' || reactionGame.phase === 'tooEarly') && (
                    <button 
                      onClick={startReactionGame}
                      className="mt-6 px-8 py-4 bg-red-600 rounded-full font-bold text-xl"
                    >
                      {reactionGame.phase === 'idle' ? 'Start' : 'Try Again'}
                    </button>
                  )}
                </div>
              )}
              
              {activeGame === 'sequence' && (
                <div className="flex flex-col items-center">
                  <div className="text-4xl font-bold mb-8">Level {sequenceGame.level}</div>
                  
                  {sequenceGame.showing ? (
                     <div className="text-9xl font-bold text-yellow-400 animate-pulse">
                       {sequenceGame.sequence[sequenceGame.sequence.length - 1]}
                     </div>
                  ) : (
                    <div className="grid grid-cols-3 gap-4">
                      {[1,2,3,4,5,6,7,8,9].map(num => (
                        <button
                          key={num}
                          onClick={() => handleSequenceInput(num)}
                          className="w-20 h-20 bg-gray-800 rounded-xl text-2xl font-bold active:bg-gray-700"
                        >
                          {num}
                        </button>
                      ))}
                    </div>
                  )}
                  
                  {sequenceGame.gameOver && (
                    <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center">
                      <div className="text-4xl font-bold text-red-500 mb-4">Game Over</div>
                      <button onClick={startSequenceGame} className="px-6 py-3 bg-white text-black rounded-full font-bold">Try Again</button>
                    </div>
                  )}
                </div>
              )}

              {activeGame === 'blocks' && (
                <div className="w-full flex flex-col items-center">
                  {/* Score Header */}
                  <div className="flex justify-between w-full max-w-sm mb-4">
                    <div className="text-center">
                      <div className="text-xs text-gray-400">SCORE</div>
                      <div className="text-2xl font-bold text-cyan-400">{blockGame.score}</div>
                    </div>
                    <div className="text-center">
                      <div className="text-xs text-gray-400">HIGH SCORE</div>
                      <div className="text-2xl font-bold text-yellow-400">{blockGame.highScore}</div>
                    </div>
                  </div>
                  
                  {/* 8x8 Grid */}
                  <div 
                    className="bg-gray-800 p-2 rounded-xl shadow-2xl border-2 border-gray-700"
                    onMouseLeave={() => setBlockGame(p => ({ ...p, ghostPosition: null }))}
                  >
                    <div className="grid grid-cols-8 gap-0.5">
                      {blockGame.grid.map((row, r) => 
                        row.map((cell, c) => {
                          const isGhost = blockGame.ghostPosition && blockGame.draggingPiece !== null && (() => {
                            const piece = blockGame.currentPieces[blockGame.draggingPiece];
                            if (!piece) return false;
                            const gr = blockGame.ghostPosition!.row;
                            const gc = blockGame.ghostPosition!.col;
                            return piece.shape.some((shapeRow, sr) => 
                              shapeRow.some((cell, sc) => 
                                cell === 1 && gr + sr === r && gc + sc === c
                              )
                            );
                          })();
                          
                          const isClearing = blockGame.clearingCells.some(
                            cc => cc.row === r && cc.col === c
                          );
                          
                          const ghostColor = blockGame.draggingPiece !== null && blockGame.currentPieces[blockGame.draggingPiece]
                            ? blockColors[blockGame.currentPieces[blockGame.draggingPiece].color]
                            : '';
                          
                          return (
                            <div
                              key={`${r}-${c}`}
                              onClick={() => placePiece(r, c)}
                              onMouseEnter={() => handleBlockDragOver(r, c)}
                              onMouseUp={() => handleBlockDrop(r, c)}
                              className={`w-8 h-8 rounded-sm transition-all cursor-pointer ${
                                isClearing 
                                  ? 'bg-white animate-pulse scale-110 shadow-[0_0_15px_rgba(255,255,255,0.8)]' 
                                  : isGhost 
                                    ? `${ghostColor} opacity-50 scale-105` 
                                    : cell === 0 
                                      ? 'bg-gray-700 hover:bg-gray-600' 
                                      : blockColors[cell]
                              } ${cell !== 0 && !isClearing ? 'shadow-inner' : ''} ${isClearing ? 'duration-300' : 'duration-100'}`}
                            />
                          );
                        })
                      )}
                    </div>
                  </div>
                  
                  {/* Available Pieces - Draggable */}
                  <div className="mt-6 flex gap-4 items-end">
                    {blockGame.currentPieces.map((piece, idx) => (
                      <div
                        key={idx}
                        draggable={!!piece}
                        onDragStart={() => handleBlockDragStart(idx)}
                        onDragEnd={handleBlockDragEnd}
                        onMouseDown={() => piece && handleBlockDragStart(idx)}
                        onMouseUp={handleBlockDragEnd}
                        onClick={() => piece && setBlockGame(p => ({ ...p, selectedPiece: idx, draggingPiece: idx }))}
                        className={`p-2 rounded-xl transition-all select-none ${
                          piece ? (blockGame.selectedPiece === idx || blockGame.draggingPiece === idx
                            ? 'bg-white/20 scale-110 ring-2 ring-cyan-400 cursor-grabbing' 
                            : 'bg-gray-800 hover:bg-gray-700 cursor-grab hover:scale-105') 
                          : 'opacity-20 cursor-not-allowed'
                        }`}
                      >
                        {piece && (
                          <div className="grid gap-0.5" style={{ gridTemplateColumns: `repeat(${piece.shape[0].length}, 1fr)` }}>
                            {piece.shape.map((row, r) =>
                              row.map((cell, c) => (
                                <div
                                  key={`${r}-${c}`}
                                  className={`w-5 h-5 rounded-sm ${cell ? blockColors[piece.color] : 'bg-transparent'}`}
                                />
                              ))
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                  
                  <p className="text-xs text-gray-500 mt-4">🖱️ Drag pieces onto the grid or click to select & place!</p>
                  
                  {/* Game Over Overlay */}
                  {blockGame.gameOver && (
                    <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center z-10">
                      <h3 className="text-4xl font-bold text-red-500 mb-2">Game Over!</h3>
                      <p className="text-2xl mb-2">Score: {blockGame.score}</p>
                      {blockGame.score >= blockGame.highScore && blockGame.score > 0 && (
                        <p className="text-yellow-400 mb-4">🏆 New High Score!</p>
                      )}
                      <button 
                        onClick={startBlockGame}
                        className="px-6 py-3 bg-cyan-600 rounded-full font-bold flex items-center gap-2"
                      >
                        <RefreshCw className="w-5 h-5" /> Play Again
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        );
      }

      return (
        <div className="p-4 space-y-6 pb-24">
          <h2 className="text-2xl font-bold">Arcade</h2>
          <div className="grid grid-cols-2 gap-4">
            {[
              { id: 'racing', name: 'F1 Racing', icon: <span className="text-3xl">🏎️</span>, color: 'bg-gradient-to-br from-red-900/40 to-orange-900/40 border-red-500/50' },
              { id: 'blocks', name: 'Block Blast', icon: <Grid className="w-8 h-8 text-cyan-400" />, color: 'bg-gradient-to-br from-cyan-900/40 to-blue-900/40 border-cyan-500/50' },
              { id: 'memory', name: 'Memory', icon: <span className="text-3xl">🧠</span>, color: 'bg-gradient-to-br from-blue-900/40 to-indigo-900/40 border-blue-500/50' },
              { id: 'reaction', name: 'F1 Lights', icon: <Zap className="w-8 h-8 text-yellow-400" />, color: 'bg-gradient-to-br from-yellow-900/40 to-amber-900/40 border-yellow-500/50' },
              { id: 'sequence', name: 'Sequence', icon: <Clock className="w-8 h-8 text-purple-400" />, color: 'bg-gradient-to-br from-purple-900/40 to-pink-900/40 border-purple-500/50' }
            ].map(game => (
              <button
                key={game.id}
                onClick={() => {
                  setActiveGame(game.id);
                  if (game.id === 'racing') startRacing();
                  if (game.id === 'blocks') startBlockGame();
                  if (game.id === 'memory') initMemoryGame();
                  if (game.id === 'reaction') {
                    setReactionGame({
                      phase: 'idle',
                      lightsOn: 0,
                      startTime: 0,
                      reactionTime: 0,
                      bestTime: reactionGame.bestTime
                    });
                  }
                  if (game.id === 'sequence') startSequenceGame();
                }}
                className={`p-6 rounded-2xl border-2 flex flex-col items-center gap-4 transition hover:scale-105 shadow-lg ${game.color}`}
              >
                {game.icon}
                <span className="font-bold">{game.name}</span>
              </button>
            ))}
          </div>

          <div className="bg-gray-50 rounded-2xl p-6">
            <h3 className="font-bold mb-4 flex items-center gap-2">
              <Trophy className="w-5 h-5 text-yellow-500" />
              Leaderboard
            </h3>
            <div className="space-y-4">
              {leaderboards.racing.map((entry, i) => (
                <div key={i} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-gray-400">#{i+1}</span>
                    <span>{entry.name}</span>
                  </div>
                  <span className="font-mono font-bold">{entry.score}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      );
    }

    if (activeTab === 'ai') {
      return (
        <div className="h-full flex flex-col bg-white pb-24">
          {/* Save Dialog Modal */}
          {showSaveDialog && (
            <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
              <div className="bg-white rounded-2xl p-6 w-full max-w-sm shadow-xl">
                <h3 className="text-lg font-bold mb-4">Save Chat</h3>
                <p className="text-sm text-gray-500 mb-4">Topic: {activeAiTopic}</p>
                <input
                  type="text"
                  value={chatNameInput}
                  onChange={(e) => setChatNameInput(e.target.value)}
                  placeholder="Enter chat name..."
                  className="w-full p-3 border border-gray-200 rounded-xl mb-4 outline-none focus:ring-2 focus:ring-purple-500"
                  autoFocus
                />
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowSaveDialog(false)}
                    className="flex-1 py-3 rounded-xl border border-gray-200 font-medium hover:bg-gray-50"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={confirmSaveChat}
                    className="flex-1 py-3 rounded-xl bg-purple-600 text-white font-medium hover:bg-purple-700"
                  >
                    Save
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Saved Sessions Panel */}
          {showSavedSessions && (
            <div className="fixed inset-0 bg-black/50 z-50 flex items-end justify-center">
              <div className="bg-white rounded-t-3xl w-full max-w-md max-h-[70vh] overflow-hidden animate-in slide-in-from-bottom">
                <div className="p-4 border-b flex items-center justify-between">
                  <h3 className="text-lg font-bold">Saved Chats</h3>
                  <button onClick={() => setShowSavedSessions(false)} className="p-2 hover:bg-gray-100 rounded-full">
                    <X className="w-5 h-5" />
                  </button>
                </div>
                <div className="p-4 overflow-y-auto max-h-[50vh]">
                  <button
                    onClick={startNewChat}
                    className="w-full p-4 mb-4 border-2 border-dashed border-purple-300 rounded-xl text-purple-600 font-medium hover:bg-purple-50 flex items-center justify-center gap-2"
                  >
                    <Plus className="w-5 h-5" />
                    Start New Chat
                  </button>
                  
                  {savedChats.length === 0 ? (
                    <p className="text-center text-gray-400 py-8">No saved chats yet</p>
                  ) : (
                    <div className="space-y-2">
                      {savedChats.map(chat => (
                        <div
                          key={chat.id}
                          className={`p-4 rounded-xl border ${currentSavedChatId === chat.id ? 'border-purple-500 bg-purple-50' : 'border-gray-200'} hover:border-purple-300 transition`}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <h4 className="font-medium text-sm">{chat.name}</h4>
                              <p className="text-xs text-gray-400">{chat.topic} • {chat.messages.length} messages</p>
                            </div>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              aiTopics.find(t => t.id === chat.topic)?.color || 'bg-gray-500'
                            } text-white`}>
                              {chat.topic}
                            </span>
                          </div>
                          <div className="flex gap-2 mt-3">
                            <button
                              onClick={() => loadSavedChat(chat)}
                              className="flex-1 py-2 rounded-lg bg-purple-600 text-white text-sm font-medium hover:bg-purple-700 flex items-center justify-center gap-1"
                            >
                              <FolderOpen className="w-4 h-4" />
                              Load
                            </button>
                            <button
                              onClick={() => deleteSavedChat(chat.id)}
                              className="py-2 px-3 rounded-lg border border-red-200 text-red-500 text-sm hover:bg-red-50"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          <div className="p-4 border-b bg-white shadow-sm z-10 sticky top-0">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-500 to-blue-600 flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="font-bold text-lg">PicDeck AI</div>
                  <div className="text-xs text-green-500 flex items-center gap-1 font-medium">
                    <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                    {currentSavedChatId ? 'Saved Session' : 'Online'}
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setShowSavedSessions(true)}
                  className="p-2 rounded-full hover:bg-gray-100 transition"
                  title="Saved Chats"
                >
                  <FolderOpen className="w-5 h-5 text-gray-600" />
                </button>
                <button
                  onClick={saveCurrentChat}
                  className="p-2 rounded-full hover:bg-gray-100 transition"
                  title="Save Chat"
                >
                  <Save className="w-5 h-5 text-gray-600" />
                </button>
              </div>
            </div>
            
            <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
              {aiTopics.map(topic => (
                <button
                  key={topic.id}
                  onClick={() => setActiveAiTopic(topic.id)}
                  className={`
                    flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-all
                    ${activeAiTopic === topic.id 
                      ? `${topic.color} text-white shadow-md scale-105` 
                      : 'bg-gray-100 text-gray-500 hover:bg-gray-200'}
                  `}
                >
                  {topic.icon}
                  {topic.id}
                </button>
              ))}
            </div>
          </div>
          
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
            {activeAiTopic === 'Art Studio' ? (
              <div className="space-y-4">
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleImageUpload}
                  accept="image/*"
                  className="hidden"
                />
                <input
                  type="file"
                  ref={videoInputRef}
                  onChange={handleVideoUpload}
                  accept="video/*"
                  className="hidden"
                />
                
                <div className="flex gap-2 mb-4">
                  <button
                    onClick={() => setEditMediaType('photo')}
                    className={`flex-1 py-3 rounded-xl font-medium flex items-center justify-center gap-2 transition ${
                      editMediaType === 'photo' ? 'bg-purple-600 text-white' : 'bg-white border border-gray-200'
                    }`}
                  >
                    <Image className="w-5 h-5" />
                    Photo
                  </button>
                  <button
                    onClick={() => setEditMediaType('video')}
                    className={`flex-1 py-3 rounded-xl font-medium flex items-center justify-center gap-2 transition ${
                      editMediaType === 'video' ? 'bg-purple-600 text-white' : 'bg-white border border-gray-200'
                    }`}
                  >
                    <Video className="w-5 h-5" />
                    Video
                  </button>
                </div>

                {editMediaType === 'photo' ? (
                  <>
                    {!uploadedImage ? (
                      <div 
                        onClick={() => fileInputRef.current?.click()}
                        className="border-2 border-dashed border-purple-300 rounded-2xl p-8 text-center cursor-pointer hover:border-purple-500 hover:bg-purple-50 transition"
                      >
                        <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                          <Wand2 className="w-8 h-8 text-purple-600" />
                        </div>
                        <h3 className="font-bold text-gray-800 mb-2">AI Art Studio</h3>
                        <p className="text-sm text-gray-500">Upload a photo as inspiration - AI will create original artwork in your chosen style</p>
                      </div>
                    ) : (
                      <div className="space-y-4">
                        <div className="relative">
                          <img 
                            src={uploadedImage} 
                            alt="Uploaded" 
                            className="w-full rounded-2xl shadow-lg"
                          />
                          <button
                            onClick={clearUpload}
                            className="absolute top-2 right-2 p-2 bg-black/50 rounded-full text-white hover:bg-black/70"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                        
                        <div className="bg-white rounded-2xl p-4 shadow-sm">
                          <h4 className="font-bold text-gray-800 mb-3">Choose a Style</h4>
                          <div className="grid grid-cols-2 gap-2">
                            {editStyles.map(style => (
                              <button
                                key={style}
                                onClick={() => setEditStyle(style)}
                                className={`p-3 rounded-xl text-sm font-medium transition ${
                                  editStyle === style
                                    ? 'bg-purple-600 text-white'
                                    : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                                }`}
                              >
                                {style}
                              </button>
                            ))}
                          </div>
                        </div>
                        
                        <button
                          onClick={handleEditImage}
                          disabled={!editStyle || isEditing}
                          className="w-full py-4 bg-gradient-to-r from-purple-600 to-pink-500 text-white rounded-xl font-bold flex items-center justify-center gap-2 disabled:opacity-50 shadow-lg"
                        >
                          {isEditing ? (
                            <>
                              <RefreshCw className="w-5 h-5 animate-spin" />
                              Creating {editStyle} version...
                            </>
                          ) : (
                            <>
                              <Wand2 className="w-5 h-5" />
                              Create {editStyle || 'Styled'} Version
                            </>
                          )}
                        </button>
                        
                        {editedImage && (
                          <div className="space-y-2">
                            <div className="flex items-center justify-between">
                              <h4 className="font-bold text-gray-800">AI Recreation:</h4>
                              <span className="text-xs text-purple-600 bg-purple-50 px-2 py-1 rounded-full">{editStyle}</span>
                            </div>
                            <img 
                              src={editedImage} 
                              alt="AI Recreation" 
                              className="w-full rounded-2xl shadow-lg"
                            />
                            <p className="text-xs text-gray-400 text-center">AI analyzed your photo and created this artistic interpretation</p>
                          </div>
                        )}
                      </div>
                    )}
                  </>
                ) : (
                  <div className="bg-gradient-to-br from-purple-100 to-pink-100 rounded-2xl p-8 text-center">
                    <div className="w-16 h-16 bg-white/50 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Video className="w-8 h-8 text-purple-600" />
                    </div>
                    <h3 className="font-bold text-gray-800 mb-2">Video Editing</h3>
                    <p className="text-sm text-gray-600 mb-4">AI video editing is coming soon!</p>
                    <p className="text-xs text-gray-500">We're working on bringing you amazing video transformation features.</p>
                  </div>
                )}
              </div>
            ) : aiMessages.length === 0 ? (
              <div className="text-center text-gray-400 mt-10 p-8">
                <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <Sparkles className="w-10 h-10 text-purple-500" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-2">Hello, {userProfile.name}!</h3>
                <p className="max-w-xs mx-auto">I'm your personal AI assistant. Select a topic above to get started.</p>
                
                <div className="grid grid-cols-2 gap-2 mt-8 max-w-xs mx-auto">
                  <button onClick={() => { setAiInput("Teach me React"); setActiveAiTopic('Coding'); }} className="p-3 bg-white border border-gray-200 rounded-xl text-xs text-left hover:border-purple-300 transition">
                    ⚛️ Teach me React
                  </button>
                  <button onClick={() => { setAiInput("What is Bitcoin?"); setActiveAiTopic('Investing'); }} className="p-3 bg-white border border-gray-200 rounded-xl text-xs text-left hover:border-purple-300 transition">
                    💰 What is Bitcoin?
                  </button>
                  <button onClick={() => { setAiInput("Value of Pi?"); setActiveAiTopic('Math'); }} className="p-3 bg-white border border-gray-200 rounded-xl text-xs text-left hover:border-purple-300 transition">
                    📐 Value of Pi?
                  </button>
                  <button onClick={() => { setAiInput("Tell me a joke"); setActiveAiTopic('General'); }} className="p-3 bg-white border border-gray-200 rounded-xl text-xs text-left hover:border-purple-300 transition">
                    😂 Tell me a joke
                  </button>
                </div>
              </div>
            ) : null}
            {aiMessages.map(msg => (
              <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2 duration-300`}>
                <div className={`max-w-[80%] p-4 rounded-2xl shadow-sm ${
                  msg.sender === 'user' 
                    ? 'bg-purple-600 text-white rounded-tr-none' 
                    : 'bg-white text-gray-800 rounded-tl-none border border-gray-100'
                }`}>
                  {msg.image ? (
                    <img src={msg.image} alt="Generated" className="rounded-lg max-w-full" />
                  ) : msg.sender === 'ai' ? (
                    <div className="prose prose-sm max-w-none prose-headings:text-gray-800 prose-p:my-1 prose-code:bg-gray-100 prose-code:px-1 prose-code:py-0.5 prose-code:rounded prose-code:text-purple-600 prose-pre:bg-gray-900 prose-pre:text-gray-100 prose-pre:rounded-lg prose-pre:p-3 prose-pre:overflow-x-auto">
                      <ReactMarkdown>{msg.text}</ReactMarkdown>
                    </div>
                  ) : (
                    msg.text
                  )}
                </div>
              </div>
            ))}
            {aiTyping && (
              <div className="flex justify-start animate-in fade-in duration-300">
                <div className="bg-white p-4 rounded-2xl rounded-tl-none border border-gray-100 shadow-sm min-w-[200px]">
                  <div className="flex items-center gap-3 mb-2">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-500 to-blue-500 flex items-center justify-center">
                      <Sparkles className="w-4 h-4 text-white animate-pulse" />
                    </div>
                    <span className="text-sm font-medium text-gray-600">
                      {activeAiTopic === 'Image' ? 'Creating your image...' : 'Thinking...'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 pl-11">
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-2 h-2 bg-purple-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-2 h-2 bg-purple-600 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-bounce" style={{ animationDelay: '450ms' }} />
                    <div className="w-2 h-2 bg-blue-400 rounded-full animate-bounce" style={{ animationDelay: '600ms' }} />
                  </div>
                  {activeAiTopic === 'Image' && (
                    <p className="text-xs text-gray-400 mt-2 pl-11 animate-pulse">This may take a moment...</p>
                  )}
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          <div className="p-4 border-t bg-white">
            <div className="flex gap-2">
              <input
                type="text"
                value={aiInput}
                onChange={(e) => setAiInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && sendAiMessage()}
                placeholder={`Ask about ${activeAiTopic}...`}
                className="flex-1 bg-gray-100 rounded-full px-4 py-3 outline-none focus:ring-2 focus:ring-purple-500 transition-all"
              />
              <button 
                onClick={sendAiMessage}
                disabled={!aiInput.trim()}
                className="p-3 bg-purple-600 rounded-full text-white hover:bg-purple-700 transition shadow-md active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      );
    }

    if (activeTab === 'profile') {
      const deckNames = ['Athletes', 'Technology', 'Movies', 'Cars', 'Artists', 'Content Creators'];
      const totalCardsPerDeck = 100;
      const totalCards = 600;
      
      const getCardCountsByDeck = () => {
        const counts: Record<string, number> = {};
        deckNames.forEach(deck => { counts[deck] = 0; });
        userCards.forEach(uc => {
          const cardDeck = getCardDeck(uc.cardId);
          if (cardDeck) {
            counts[cardDeck] = (counts[cardDeck] || 0) + uc.quantity;
          }
        });
        return counts;
      };
      
      const cardCountsByDeck = getCardCountsByDeck();
      const totalCollected = userCards.reduce((sum, uc) => sum + uc.quantity, 0);
      const uniqueCards = userCards.length;
      
      const toggleTradeCardSelection = (cardId: number) => {
        setSelectedTradeCards(prev => 
          prev.includes(cardId) 
            ? prev.filter(id => id !== cardId)
            : [...prev, cardId]
        );
      };

      return (
        <div className="p-4 space-y-4 overflow-y-auto">
          <div className="bg-white rounded-2xl p-4 shadow-sm text-center">
            <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full flex items-center justify-center mx-auto mb-3">
              <span className="text-3xl text-white">{userProfile.name?.charAt(0)?.toUpperCase() || '?'}</span>
            </div>
            <h2 className="text-xl font-bold text-gray-800">{userProfile.name}</h2>
            <p className="text-gray-500 text-sm">@{userProfile.username || 'user'}</p>
          </div>
          
          <div className="flex bg-gray-100 rounded-xl p-1">
            {(['stats', 'collection', 'trading', 'settings'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => setProfileTab(tab)}
                className={`flex-1 py-2 text-xs font-medium rounded-lg transition capitalize ${
                  profileTab === tab 
                    ? 'bg-white text-purple-600 shadow-sm' 
                    : 'text-gray-500'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {profileTab === 'stats' && (
            <div className="space-y-4">
              <div className="bg-white rounded-2xl p-4 shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-3">Collection Overview</h3>
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="text-center p-3 bg-purple-50 rounded-xl">
                    <p className="text-xl font-bold text-purple-600">{totalCollected}</p>
                    <p className="text-xs text-gray-500">Total Cards</p>
                  </div>
                  <div className="text-center p-3 bg-blue-50 rounded-xl">
                    <p className="text-xl font-bold text-blue-600">{uniqueCards}</p>
                    <p className="text-xs text-gray-500">Unique</p>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-xl">
                    <p className="text-xl font-bold text-green-600">{Math.round((uniqueCards / totalCards) * 100)}%</p>
                    <p className="text-xs text-gray-500">Complete</p>
                  </div>
                </div>
                <div className="space-y-2">
                  {deckNames.map(deck => (
                    <div key={deck} className="flex items-center justify-between py-2 border-b border-gray-100 last:border-0">
                      <span className="text-sm text-gray-700">{deck}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-24 h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-purple-500 rounded-full transition-all"
                            style={{ width: `${(cardCountsByDeck[deck] / totalCardsPerDeck) * 100}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-500 w-12 text-right">
                          {cardCountsByDeck[deck]}/{totalCardsPerDeck}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {profileTab === 'collection' && (
            <div className="space-y-4">
              <div className="flex gap-2 overflow-x-auto pb-2">
                <button
                  onClick={() => setCollectionFilter('all')}
                  className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition ${
                    collectionFilter === 'all' ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-600'
                  }`}
                >
                  All ({uniqueCards})
                </button>
                {deckNames.map(deck => (
                  <button
                    key={deck}
                    onClick={() => setCollectionFilter(deck)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition ${
                      collectionFilter === deck ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {deck} ({cardCountsByDeck[deck]})
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-3 gap-2">
                {userCards
                  .filter(uc => collectionFilter === 'all' || getCardDeck(uc.cardId) === collectionFilter)
                  .map(uc => {
                    const card = getCardById(uc.cardId);
                    const rarity = getCardRarity(uc.cardId);
                    if (!card) return null;
                    return (
                      <div 
                        key={uc.id} 
                        className={`bg-white rounded-xl p-2 shadow-sm border-2 ${
                          rarity === 'One-in-a-Million' ? 'border-yellow-400 bg-yellow-50' :
                          rarity === 'Iconic' ? 'border-purple-400 bg-purple-50' :
                          rarity === 'Legendary' ? 'border-orange-400 bg-orange-50' :
                          rarity === 'Epic' ? 'border-pink-400 bg-pink-50' :
                          rarity === 'Rare' ? 'border-blue-400 bg-blue-50' :
                          'border-gray-200'
                        }`}
                      >
                        <div className="text-2xl text-center mb-1">{card.image}</div>
                        <p className="text-xs font-medium text-center text-gray-800 truncate">{card.name}</p>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-[10px] text-gray-400">{rarity}</span>
                          {uc.quantity > 1 && (
                            <span className="text-[10px] bg-purple-100 text-purple-600 px-1.5 rounded-full">x{uc.quantity}</span>
                          )}
                        </div>
                      </div>
                    );
                  })}
              </div>
              {userCards.length === 0 && (
                <div className="text-center py-8 text-gray-400">
                  <Package className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p>No cards collected yet!</p>
                  <p className="text-sm">Open packs to start your collection</p>
                </div>
              )}
            </div>
          )}

          {profileTab === 'trading' && (
            <div className="space-y-4">
              {!showCreateTrade ? (
                <>
                  <button
                    onClick={() => setShowCreateTrade(true)}
                    className="w-full bg-purple-600 text-white py-3 rounded-xl font-medium flex items-center justify-center gap-2"
                  >
                    <Repeat className="w-4 h-4" />
                    Create New Trade
                  </button>
                  
                  <div className="bg-white rounded-2xl p-4 shadow-sm">
                    <h3 className="font-semibold text-gray-800 mb-3">Available Trades</h3>
                    {trades.filter(t => t.fromUserId !== currentUserId && t.status === 'pending').length === 0 ? (
                      <p className="text-center text-gray-400 py-4">No trades available</p>
                    ) : (
                      <div className="space-y-3">
                        {trades
                          .filter(t => t.fromUserId !== currentUserId && t.status === 'pending')
                          .map(trade => {
                            const trader = allUsers.find(u => u.id === trade.fromUserId);
                            return (
                              <div key={trade.id} className="border border-gray-100 rounded-xl p-3">
                                <div className="flex items-center justify-between mb-2">
                                  <span className="text-sm font-medium">{trader?.username || 'Unknown'}</span>
                                  <span className="text-xs text-gray-400">offers {trade.offeredCardIds.length} cards</span>
                                </div>
                                <div className="flex flex-wrap gap-1 mb-2">
                                  {trade.offeredCardIds.slice(0, 4).map(cardId => {
                                    const card = getCardById(cardId);
                                    return card ? (
                                      <span key={cardId} className="text-lg">{card.image}</span>
                                    ) : null;
                                  })}
                                  {trade.offeredCardIds.length > 4 && (
                                    <span className="text-xs text-gray-400">+{trade.offeredCardIds.length - 4} more</span>
                                  )}
                                </div>
                                <button
                                  onClick={() => acceptTrade(trade.id)}
                                  className="w-full bg-green-500 text-white py-2 rounded-lg text-sm font-medium flex items-center justify-center gap-1"
                                >
                                  <Check className="w-4 h-4" />
                                  Accept Trade
                                </button>
                              </div>
                            );
                          })}
                      </div>
                    )}
                  </div>

                  <div className="bg-white rounded-2xl p-4 shadow-sm">
                    <h3 className="font-semibold text-gray-800 mb-3">Your Active Trades</h3>
                    {trades.filter(t => t.fromUserId === currentUserId && t.status === 'pending').length === 0 ? (
                      <p className="text-center text-gray-400 py-4">No active trades</p>
                    ) : (
                      <div className="space-y-3">
                        {trades
                          .filter(t => t.fromUserId === currentUserId && t.status === 'pending')
                          .map(trade => (
                            <div key={trade.id} className="border border-gray-100 rounded-xl p-3">
                              <div className="flex items-center justify-between mb-2">
                                <span className="text-xs text-gray-400">Offering {trade.offeredCardIds.length} cards</span>
                                <button
                                  onClick={() => cancelTrade(trade.id)}
                                  className="text-red-500 text-xs"
                                >
                                  Cancel
                                </button>
                              </div>
                              <div className="flex flex-wrap gap-1">
                                {trade.offeredCardIds.map(cardId => {
                                  const card = getCardById(cardId);
                                  return card ? (
                                    <span key={cardId} className="text-lg">{card.image}</span>
                                  ) : null;
                                })}
                              </div>
                            </div>
                          ))}
                      </div>
                    )}
                  </div>
                </>
              ) : (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="font-semibold text-gray-800">Select Cards to Trade</h3>
                    <button
                      onClick={() => { setShowCreateTrade(false); setSelectedTradeCards([]); }}
                      className="text-gray-400"
                    >
                      <X className="w-5 h-5" />
                    </button>
                  </div>
                  <div className="grid grid-cols-4 gap-2">
                    {userCards.map(uc => {
                      const card = getCardById(uc.cardId);
                      if (!card) return null;
                      const isSelected = selectedTradeCards.includes(uc.cardId);
                      return (
                        <button
                          key={uc.id}
                          onClick={() => toggleTradeCardSelection(uc.cardId)}
                          className={`p-2 rounded-xl border-2 transition ${
                            isSelected ? 'border-purple-500 bg-purple-50' : 'border-gray-200 bg-white'
                          }`}
                        >
                          <span className="text-xl">{card.image}</span>
                          {isSelected && (
                            <Check className="w-3 h-3 text-purple-600 mx-auto mt-1" />
                          )}
                        </button>
                      );
                    })}
                  </div>
                  {selectedTradeCards.length > 0 && (
                    <button
                      onClick={createTrade}
                      className="w-full bg-purple-600 text-white py-3 rounded-xl font-medium"
                    >
                      Create Trade ({selectedTradeCards.length} cards)
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          {profileTab === 'settings' && (
            <div className="space-y-4">
              <div className="bg-white rounded-2xl p-4 shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-3">Change Deck</h3>
                <p className="text-sm text-gray-500 mb-3">Select which deck to open packs from:</p>
                <div className="grid grid-cols-2 gap-2">
                  {deckNames.map(deck => (
                    <button
                      key={deck}
                      onClick={() => updateSelectedDeck(deck)}
                      className={`p-3 rounded-xl text-sm font-medium transition ${
                        userProfile.selectedDeck === deck
                          ? 'bg-purple-600 text-white'
                          : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {deck}
                    </button>
                  ))}
                </div>
              </div>
              
              <div className="bg-white rounded-2xl p-4 shadow-sm">
                <h3 className="font-semibold text-gray-800 mb-3">Account</h3>
                <p className="text-sm text-gray-500 mb-1">Email: {userProfile.email}</p>
                <p className="text-sm text-gray-500">Username: @{userProfile.username}</p>
              </div>
              
              <button 
                onClick={handleLogout}
                data-testid="button-logout"
                className="w-full bg-red-50 text-red-600 py-3 rounded-xl font-medium hover:bg-red-100 transition"
              >
                Log Out
              </button>
            </div>
          )}
        </div>
      );
    }

    return (
      <div className="flex items-center justify-center h-full text-gray-400">
        Coming Soon
      </div>
    );
  };

  // Screen Routing
  if (currentScreen === 'landing') {
    return (
      <div className="min-h-screen bg-gradient-to-b from-purple-600 to-blue-600 flex flex-col p-6">
        <div className="flex-1 flex flex-col justify-center max-w-md mx-auto w-full text-center">
          <div className="mb-12">
            <div className="w-24 h-24 bg-white/20 backdrop-blur rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl">
              <Sparkles className="w-12 h-12 text-white" />
            </div>
            <h1 className="text-5xl font-bold text-white mb-3">PicDeck</h1>
            <p className="text-white/80 text-lg">Collect. Play. Connect.</p>
          </div>
          
          <div className="space-y-4">
            <button 
              onClick={() => { setAuthMode('login'); setCurrentScreen('auth'); setAuthError(''); }}
              data-testid="button-login"
              className="w-full bg-white text-purple-600 py-4 rounded-xl font-bold text-lg hover:bg-gray-100 transition shadow-lg"
            >
              Log In
            </button>
            <button 
              onClick={() => { setAuthMode('signup'); setCurrentScreen('auth'); setAuthError(''); }}
              data-testid="button-signup"
              className="w-full bg-transparent border-2 border-white text-white py-4 rounded-xl font-bold text-lg hover:bg-white/10 transition"
            >
              Create Account
            </button>
          </div>
          
          <p className="text-white/60 text-sm mt-8">
            Trade cards, play games, and chat with AI
          </p>
        </div>
      </div>
    );
  }

  if (currentScreen === 'auth') {
    return (
      <div className="min-h-screen bg-white flex flex-col p-6">
        <button 
          onClick={() => setCurrentScreen('landing')}
          className="self-start mb-4 p-2 hover:bg-gray-100 rounded-lg transition"
        >
          <ArrowLeft className="w-6 h-6 text-gray-600" />
        </button>
        
        <div className="flex-1 flex flex-col justify-center max-w-md mx-auto w-full">
          <div className="mb-8 text-center">
            <h1 className="text-4xl font-bold text-purple-600 mb-2">PicDeck</h1>
            <p className="text-gray-500">{authMode === 'login' ? 'Welcome back!' : 'Create your account'}</p>
          </div>

          {authError && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-600 rounded-xl text-sm">
              {authError}
            </div>
          )}
          
          {authMode === 'login' ? (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input 
                  type="email" 
                  value={loginData.email}
                  onChange={e => setLoginData({...loginData, email: e.target.value})}
                  data-testid="input-login-email"
                  className="w-full p-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 outline-none"
                  placeholder="john@example.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <input 
                  type="password" 
                  value={loginData.password}
                  onChange={e => setLoginData({...loginData, password: e.target.value})}
                  data-testid="input-login-password"
                  className="w-full p-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 outline-none"
                  placeholder="••••••••"
                />
              </div>
              
              <button 
                onClick={handleLogin}
                disabled={authLoading}
                data-testid="button-submit-login"
                className="w-full bg-purple-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-purple-700 transition mt-4 disabled:opacity-50"
              >
                {authLoading ? 'Logging in...' : 'Log In'}
              </button>
              
              <p className="text-center text-gray-500 mt-4">
                Don't have an account?{' '}
                <button 
                  onClick={() => { setAuthMode('signup'); setAuthError(''); }}
                  className="text-purple-600 font-medium hover:underline"
                >
                  Sign Up
                </button>
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                <input 
                  type="text" 
                  value={signUpData.name}
                  onChange={e => setSignUpData({...signUpData, name: e.target.value})}
                  data-testid="input-signup-name"
                  className="w-full p-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 outline-none"
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
                <input 
                  type="text" 
                  value={signUpData.username}
                  onChange={e => setSignUpData({...signUpData, username: e.target.value})}
                  data-testid="input-signup-username"
                  className="w-full p-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 outline-none"
                  placeholder="johndoe"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input 
                  type="email" 
                  value={signUpData.email}
                  onChange={e => setSignUpData({...signUpData, email: e.target.value})}
                  data-testid="input-signup-email"
                  className="w-full p-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 outline-none"
                  placeholder="john@example.com"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <input 
                  type="password" 
                  value={signUpData.password}
                  onChange={e => setSignUpData({...signUpData, password: e.target.value})}
                  data-testid="input-signup-password"
                  className="w-full p-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 outline-none"
                  placeholder="••••••••"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Date of Birth</label>
                <input 
                  type="date" 
                  value={signUpData.birthDate}
                  onChange={e => setSignUpData({...signUpData, birthDate: e.target.value})}
                  data-testid="input-signup-birthdate"
                  className="w-full p-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-purple-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Starter Deck</label>
                <div className="grid grid-cols-2 gap-2">
                  {Object.keys(deckCards).map(deck => (
                    <button
                      key={deck}
                      onClick={() => setSignUpData({...signUpData, selectedDeck: deck})}
                      data-testid={`button-deck-${deck}`}
                      className={`p-3 rounded-xl border-2 text-sm font-medium transition ${
                        signUpData.selectedDeck === deck 
                          ? 'border-purple-500 bg-purple-50 text-purple-700' 
                          : 'border-gray-100 hover:border-gray-200'
                      }`}
                    >
                      {deck}
                    </button>
                  ))}
                </div>
              </div>
              
              <button 
                onClick={handleSignUp}
                disabled={authLoading}
                data-testid="button-submit-signup"
                className="w-full bg-purple-600 text-white py-4 rounded-xl font-bold text-lg hover:bg-purple-700 transition mt-4 disabled:opacity-50"
              >
                {authLoading ? 'Creating Account...' : 'Create Account'}
              </button>
              
              <p className="text-center text-gray-500 mt-4">
                Already have an account?{' '}
                <button 
                  onClick={() => { setAuthMode('login'); setAuthError(''); }}
                  className="text-purple-600 font-medium hover:underline"
                >
                  Log In
                </button>
              </p>
            </div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white max-w-md mx-auto relative shadow-2xl overflow-hidden">
      {/* Top Bar */}
      <div className="h-14 border-b flex items-center justify-between px-4 bg-white z-10 relative">
        <h1 className="font-bold text-xl bg-clip-text text-transparent bg-gradient-to-r from-purple-600 to-blue-600">
          PicDeck
        </h1>
        <div className="flex items-center gap-4">
          <button onClick={startCamera}>
             <Camera className="w-6 h-6 text-gray-700" />
          </button>
          <button onClick={() => setActiveTab('messages')}>
             <MessageCircle className="w-6 h-6 text-gray-700" />
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="h-[calc(100vh-7rem)] overflow-y-auto bg-gray-50 scrollbar-hide">
        {renderContent()}
      </div>

      {/* Bottom Navigation */}
      <div className="h-16 border-t bg-white fixed bottom-0 w-full max-w-md flex items-center justify-around px-2 z-10 pb-safe">
        <button onClick={() => setActiveTab('home')} className={`p-2 ${activeTab === 'home' ? 'text-purple-600' : 'text-gray-400'}`}>
          <Home className="w-6 h-6" />
        </button>
        <button onClick={() => setActiveTab('games')} className={`p-2 ${activeTab === 'games' ? 'text-purple-600' : 'text-gray-400'}`}>
          <Grid className="w-6 h-6" />
        </button>
        <button onClick={() => setActiveTab('ai')} className={`p-2 ${activeTab === 'ai' ? 'text-purple-600' : 'text-gray-400'}`}>
          <div className={`w-10 h-10 rounded-full flex items-center justify-center -mt-6 shadow-lg border-4 border-white ${activeTab === 'ai' ? 'bg-purple-600 text-white' : 'bg-gray-900 text-white'}`}>
            <Sparkles className="w-5 h-5" />
          </div>
        </button>
        <button onClick={() => setActiveTab('collection')} className={`p-2 ${activeTab === 'collection' ? 'text-purple-600' : 'text-gray-400'}`}>
          <Film className="w-6 h-6" />
        </button>
        <button onClick={() => setActiveTab('profile')} className={`p-2 ${activeTab === 'profile' ? 'text-purple-600' : 'text-gray-400'}`}>
          <User className="w-6 h-6" />
        </button>
      </div>
    </div>
  );
}
