import PicDeckPlatform from "@/components/PicDeckPlatform";

export default function Home() {
  return <PicDeckPlatform />;
}
