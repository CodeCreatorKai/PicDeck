export const aiKnowledgeBase: Record<string, string[]> = {
  // GREETINGS & BASICS
  "hello": ["Hello! How can I help you today?", "Hi there! Ready to learn something new?", "Greetings! What's on your mind?"],
  "hi": ["Hello! How can I help you today?", "Hi there! Ready to learn something new?", "Greetings! What's on your mind?"],
  "hey": ["Hey! How's it going?", "Hello! What can I do for you?", "Hi! Ready to chat?"],
  "who are you": ["I'm PicDeck AI, your virtual assistant.", "I'm a simulated AI helper built for PicDeck.", "I'm your study buddy and creative assistant!"],
  "what can you do": ["I can answer questions about coding, math, investing, and more!", "I can help you learn, solve problems, or just chat.", "Try asking me about React, Bitcoin, or Algebra!"],
  
  // CODING - REACT
  "react": ["React is a JS library for building UIs. It uses components.", "React makes building interactive UIs simple with state and props.", "React's virtual DOM ensures high performance."],
  "jsx": ["JSX is a syntax extension for JavaScript. It looks like XML/HTML.", "JSX allows you to write HTML-like code inside JavaScript.", "React uses JSX to describe what the UI should look like."],
  "hook": ["Hooks allow functional components to use state and lifecycle features.", "Common hooks include useState, useEffect, and useContext.", "Hooks were introduced in React 16.8."],
  "component": ["Components are the building blocks of React apps.", "A component can be a function or a class.", "Components let you split the UI into independent, reusable pieces."],
  
  // CODING - PYTHON
  "python": ["Python is a high-level, interpreted programming language.", "Python is famous for its readability and simple syntax.", "Python is great for web dev, data science, and AI."],
  "list": ["Lists in Python are ordered, mutable collections.", "You can create a list with square brackets: my_list = [1, 2, 3].", "Lists can contain items of different types."],
  "loop": ["For loops and While loops are used for iteration.", "A for loop iterates over a sequence (like a list or string).", "Be careful with while loops to avoid infinite loops!"],
  
  // INVESTING
  "bitcoin": ["Bitcoin is the first decentralized cryptocurrency.", "Bitcoin uses blockchain technology to record transactions.", "Bitcoin is often referred to as 'digital gold'."],
  "crypto": ["Cryptocurrency is a digital or virtual currency secured by cryptography.", "Popular cryptos include Bitcoin, Ethereum, and Solana.", "Crypto markets are highly volatile, so invest carefully."],
  "stock": ["A stock represents a share in the ownership of a company.", "Owning stock gives you a claim on part of the company's assets and earnings.", "Stocks are bought and sold on stock exchanges."],
  "diversification": ["Diversification means not putting all your eggs in one basket.", "It helps reduce risk by spreading investments across different assets.", "A diversified portfolio might include stocks, bonds, and real estate."],
  
  // MATH
  "pi": ["Pi (π) is the ratio of a circle's circumference to its diameter.", "Pi is approximately 3.14159.", "Pi is an irrational number, meaning its decimals go on forever."],
  "algebra": ["Algebra uses symbols (variables) to represent numbers in equations.", "It helps solve problems where some values are unknown.", "Common variables are x, y, and z."],
  "geometry": ["Geometry is the branch of math concerned with shapes and space.", "It deals with points, lines, surfaces, and solids.", "Euclid is often called the 'father of geometry'."],
  "calculus": ["Calculus is the mathematical study of continuous change.", "It has two major branches: differential and integral calculus.", "Isaac Newton and Gottfried Leibniz developed calculus."],
  
  // SCIENCE
  "atom": ["An atom is the smallest unit of ordinary matter.", "Atoms are made of protons, neutrons, and electrons.", "Everything you see is made of atoms."],
  "gravity": ["Gravity is a force that attracts two bodies toward each other.", "Earth's gravity keeps us on the ground.", "Gravity is what keeps planets in orbit around the sun."],
  "photosynthesis": ["Photosynthesis is how plants make food using sunlight.", "It converts carbon dioxide and water into glucose and oxygen.", "Chlorophyll is the green pigment that makes it possible."],
  
  // HISTORY
  "rome": ["Ancient Rome was a powerful civilization that lasted for over 1000 years.", "It began as a small town on the Tiber River in Italy.", "The Roman Empire surrounded the Mediterranean Sea."],
  "ww2": ["World War II lasted from 1939 to 1945.", "It involved the vast majority of the world's countries.", "The two opposing alliances were the Allies and the Axis."],
  
  // FUN
  "joke": ["Why did the developer go broke? Because he used up all his cache!", "Why do programmers prefer dark mode? Because light attracts bugs.", "What do you call a fake noodle? An impasta!"],
  "riddle": ["I speak without a mouth and hear without ears. I have no body, but I come alive with wind. What am I? (A Echo)", "The more of this there is, the less you see. What is it? (Darkness)"],
  
  // DEFAULT FALLBACKS
  "default": [
    "That's an interesting topic! Tell me more about it.",
    "I'm still learning about that. Could you be more specific?",
    "I don't have the exact answer, but I'd love to explore that with you.",
    "Could you rephrase that? I want to make sure I understand.",
    "That's a deep question. What are your thoughts on it?"
  ]
};

export const findAiResponse = (input: string): string => {
  const lowerInput = input.toLowerCase();
  
  // Check for direct keyword matches
  for (const key in aiKnowledgeBase) {
    if (lowerInput.includes(key)) {
      const responses = aiKnowledgeBase[key];
      return responses[Math.floor(Math.random() * responses.length)];
    }
  }
  
  // Fallback
  const defaults = aiKnowledgeBase["default"];
  return defaults[Math.floor(Math.random() * defaults.length)];
};
