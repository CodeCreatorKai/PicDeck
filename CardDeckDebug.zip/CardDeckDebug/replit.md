# PicDeck Platform

## Overview

PicDeck is a social platform centered around collectible cards, games, and AI-powered chat. Users can sign up, collect cards from various themed decks (Athletes, Technology, Movies, Cars, Artists, Content Creators), interact with an AI assistant, and engage with a social feed. The platform combines gamification elements with social features and AI integration.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for client-side routing
- **State Management**: TanStack React Query for server state
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS v4 with custom CSS variables for theming
- **Build Tool**: Vite with custom plugins for Replit integration

The main application component is `PicDeckPlatform.tsx` which handles multiple screens (landing, auth, main app) with state-based navigation rather than route-based navigation.

### Backend Architecture
- **Runtime**: Node.js with Express
- **Language**: TypeScript compiled with tsx for development and esbuild for production
- **API Design**: RESTful endpoints under `/api` prefix
- **Development Server**: Vite middleware integration for hot module replacement

Key API routes include:
- `/api/auth/signup` - User registration
- `/api/auth/login` - User authentication
- `/api/chat` - AI chat integration via OpenAI API
- `/api/saved-chats` - CRUD operations for saved chat sessions

### Data Storage
- **Database**: PostgreSQL via Neon serverless
- **ORM**: Drizzle ORM with drizzle-zod for schema validation
- **Schema Location**: `shared/schema.ts` contains all table definitions

Current tables:
- `users` - User accounts with authentication data and game state (packs available, selected deck)
- `savedChats` - Persisted AI chat sessions with JSON message storage

### Authentication
- Simple password hashing using SHA-256 (note: production should use bcrypt or similar)
- Session-based authentication using express-session with PostgreSQL session store via connect-pg-simple
- No JWT or OAuth integration currently

### AI Integration
- OpenAI API integration for chat functionality
- Environment variables: `AI_INTEGRATIONS_OPENAI_API_KEY` and `AI_INTEGRATIONS_OPENAI_BASE_URL`
- Local knowledge base fallback in `client/src/data/ai-knowledge.ts` for topic-specific responses

### Build System
- Development: Vite dev server with HMR
- Production: Custom build script using esbuild for server bundling and Vite for client
- Output: `dist/public` for client assets, `dist/index.cjs` for server bundle

## External Dependencies

### Database
- **Neon PostgreSQL**: Serverless PostgreSQL database
- **Connection**: `DATABASE_URL` environment variable required
- **Session Store**: `connect-pg-simple` for Express session storage

### AI Services
- **OpenAI API**: Primary AI chat provider
- **Configuration**: Requires `AI_INTEGRATIONS_OPENAI_API_KEY` and `AI_INTEGRATIONS_OPENAI_BASE_URL` environment variables

### Third-Party UI Libraries
- **Radix UI**: Headless component primitives for accessibility
- **Lucide React**: Icon library
- **React Markdown**: Markdown rendering for AI responses
- **Embla Carousel**: Carousel component
- **Vaul**: Drawer component
- **React Day Picker**: Calendar component

### Replit-Specific Integrations
- `@replit/vite-plugin-runtime-error-modal`: Error overlay in development
- `@replit/vite-plugin-cartographer`: Development tooling
- `@replit/vite-plugin-dev-banner`: Development banner
- Custom `vite-plugin-meta-images`: OpenGraph image URL handling for Replit deployments