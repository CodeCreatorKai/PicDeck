import { 
  type User, type InsertUser, 
  type SavedChat, type InsertSavedChat,
  type UserCard, type InsertUserCard,
  type Trade, type InsertTrade,
  users, savedChats, userCards, trades 
} from "@shared/schema";
import { db } from "./db";
import { eq, and, ne } from "drizzle-orm";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  
  getSavedChatsByUserId(userId: string): Promise<SavedChat[]>;
  createSavedChat(chat: InsertSavedChat): Promise<SavedChat>;
  updateSavedChat(id: string, updates: Partial<SavedChat>): Promise<SavedChat | undefined>;
  deleteSavedChat(id: string): Promise<void>;

  getUserCards(userId: string): Promise<UserCard[]>;
  addUserCard(userId: string, cardId: number): Promise<UserCard>;
  removeUserCard(userId: string, cardId: number): Promise<void>;
  
  getTrades(): Promise<Trade[]>;
  getTradesByUserId(userId: string): Promise<Trade[]>;
  createTrade(trade: InsertTrade): Promise<Trade>;
  updateTrade(id: string, updates: Partial<Trade>): Promise<Trade | undefined>;
  deleteTrade(id: string): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async getSavedChatsByUserId(userId: string): Promise<SavedChat[]> {
    return await db.select().from(savedChats).where(eq(savedChats.userId, userId));
  }

  async createSavedChat(chat: InsertSavedChat): Promise<SavedChat> {
    const [saved] = await db.insert(savedChats).values(chat).returning();
    return saved;
  }

  async updateSavedChat(id: string, updates: Partial<SavedChat>): Promise<SavedChat | undefined> {
    const [updated] = await db
      .update(savedChats)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(savedChats.id, id))
      .returning();
    return updated;
  }

  async deleteSavedChat(id: string): Promise<void> {
    await db.delete(savedChats).where(eq(savedChats.id, id));
  }

  async getUserCards(userId: string): Promise<UserCard[]> {
    return await db.select().from(userCards).where(eq(userCards.userId, userId));
  }

  async addUserCard(userId: string, cardId: number): Promise<UserCard> {
    const existing = await db.select().from(userCards)
      .where(and(eq(userCards.userId, userId), eq(userCards.cardId, cardId)));
    
    if (existing.length > 0) {
      const [updated] = await db.update(userCards)
        .set({ quantity: (existing[0].quantity || 1) + 1 })
        .where(eq(userCards.id, existing[0].id))
        .returning();
      return updated;
    }
    
    const [card] = await db.insert(userCards).values({ userId, cardId, quantity: 1 }).returning();
    return card;
  }

  async removeUserCard(userId: string, cardId: number): Promise<void> {
    const existing = await db.select().from(userCards)
      .where(and(eq(userCards.userId, userId), eq(userCards.cardId, cardId)));
    
    if (existing.length > 0 && existing[0].quantity > 1) {
      await db.update(userCards)
        .set({ quantity: existing[0].quantity - 1 })
        .where(eq(userCards.id, existing[0].id));
    } else if (existing.length > 0) {
      await db.delete(userCards).where(eq(userCards.id, existing[0].id));
    }
  }

  async getTrades(): Promise<Trade[]> {
    return await db.select().from(trades).where(eq(trades.status, 'pending'));
  }

  async getTradesByUserId(userId: string): Promise<Trade[]> {
    return await db.select().from(trades).where(eq(trades.fromUserId, userId));
  }

  async createTrade(trade: InsertTrade): Promise<Trade> {
    const [created] = await db.insert(trades).values(trade).returning();
    return created;
  }

  async updateTrade(id: string, updates: Partial<Trade>): Promise<Trade | undefined> {
    const [updated] = await db.update(trades).set(updates).where(eq(trades.id, id)).returning();
    return updated;
  }

  async deleteTrade(id: string): Promise<void> {
    await db.delete(trades).where(eq(trades.id, id));
  }
}

export const storage = new DatabaseStorage();
