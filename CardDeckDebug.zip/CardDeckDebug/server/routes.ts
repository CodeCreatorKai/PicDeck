import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import OpenAI from "openai";
import { z } from "zod";
import { insertUserSchema, loginSchema, insertSavedChatSchema } from "@shared/schema";
import crypto from "crypto";

const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

const chatRequestSchema = z.object({
  message: z.string().min(1),
  topic: z.enum(['General', 'Coding', 'Investing', 'Math']).optional(),
});

const imageRequestSchema = z.object({
  prompt: z.string().min(1),
});

// Simple password hashing
function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Auth: Sign up
  app.post("/api/auth/signup", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(userData.email);
      if (existingEmail) {
        return res.status(400).json({ error: "Email already registered" });
      }
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(userData.username);
      if (existingUsername) {
        return res.status(400).json({ error: "Username already taken" });
      }
      
      // Hash password and create user
      const hashedPassword = hashPassword(userData.password);
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });
      
      // Don't return password
      const { password, ...safeUser } = user;
      res.json({ user: safeUser });
    } catch (error) {
      console.error("Signup error:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid input data" });
      } else {
        res.status(500).json({ error: "Failed to create account" });
      }
    }
  });

  // Auth: Login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = loginSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
      
      const hashedPassword = hashPassword(password);
      if (user.password !== hashedPassword) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
      
      // Don't return password
      const { password: _, ...safeUser } = user;
      res.json({ user: safeUser });
    } catch (error) {
      console.error("Login error:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid input format" });
      } else {
        res.status(500).json({ error: "Failed to login" });
      }
    }
  });

  // Saved Chats: Get all for user
  app.get("/api/chats/:userId", async (req, res) => {
    try {
      const chats = await storage.getSavedChatsByUserId(req.params.userId);
      res.json({ chats });
    } catch (error) {
      console.error("Get chats error:", error);
      res.status(500).json({ error: "Failed to fetch chats" });
    }
  });

  // Saved Chats: Create
  app.post("/api/chats", async (req, res) => {
    try {
      const chatData = insertSavedChatSchema.parse(req.body);
      const chat = await storage.createSavedChat(chatData);
      res.json({ chat });
    } catch (error) {
      console.error("Create chat error:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid chat data" });
      } else {
        res.status(500).json({ error: "Failed to save chat" });
      }
    }
  });

  // Saved Chats: Update
  app.patch("/api/chats/:id", async (req, res) => {
    try {
      const chat = await storage.updateSavedChat(req.params.id, req.body);
      if (!chat) {
        return res.status(404).json({ error: "Chat not found" });
      }
      res.json({ chat });
    } catch (error) {
      console.error("Update chat error:", error);
      res.status(500).json({ error: "Failed to update chat" });
    }
  });

  // Saved Chats: Delete
  app.delete("/api/chats/:id", async (req, res) => {
    try {
      await storage.deleteSavedChat(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete chat error:", error);
      res.status(500).json({ error: "Failed to delete chat" });
    }
  });

  // AI Chat endpoint
  app.post("/api/chat", async (req, res) => {
    try {
      const { message, topic } = chatRequestSchema.parse(req.body);
      
      // Build system prompt based on topic
      let systemPrompt = "You are a helpful AI assistant in the PicDeck app. Provide clear, concise, and educational responses.";
      
      if (topic === 'Coding') {
        systemPrompt = "You are a coding expert assistant. Help users learn programming concepts, debug code, and understand best practices. Provide clear explanations with examples when helpful.";
      } else if (topic === 'Investing') {
        systemPrompt = "You are a financial education assistant. Help users understand investing concepts, market basics, and personal finance. Always remind users that this is educational information, not financial advice.";
      } else if (topic === 'Math') {
        systemPrompt = "You are a math tutor. Help users understand mathematical concepts, solve problems step-by-step, and explain the reasoning behind solutions.";
      }
      
      const completion = await openai.chat.completions.create({
        model: "gpt-4o-mini",
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user", content: message }
        ],
        max_tokens: 500,
        temperature: 0.7,
      });
      
      const response = completion.choices[0]?.message?.content || "I'm sorry, I couldn't generate a response.";
      
      res.json({ response });
    } catch (error) {
      console.error("Chat error:", error);
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid request format" });
      } else {
        res.status(500).json({ error: "Failed to process chat request" });
      }
    }
  });

  // AI Image generation endpoint
  app.post("/api/generate-image", async (req, res) => {
    try {
      const { prompt } = imageRequestSchema.parse(req.body);
      
      const response = await openai.images.generate({
        model: "gpt-image-1",
        prompt: prompt,
        n: 1,
        size: "1024x1024",
      });
      
      const imageData = response.data?.[0];
      if (!imageData) {
        throw new Error("No image generated");
      }
      
      const imageUrl = imageData.url || imageData.b64_json;
      
      if (!imageUrl) {
        throw new Error("No image URL generated");
      }
      
      // If it's base64, prefix it properly
      const finalUrl = imageData.b64_json 
        ? `data:image/png;base64,${imageData.b64_json}`
        : imageUrl;
      
      res.json({ imageUrl: finalUrl });
    } catch (error) {
      console.error("Image generation error:", error);
      res.status(500).json({ error: "Failed to generate image" });
    }
  });

  // User cards endpoints
  app.get("/api/cards/:userId", async (req, res) => {
    try {
      const cards = await storage.getUserCards(req.params.userId);
      res.json({ cards });
    } catch (error) {
      console.error("Get cards error:", error);
      res.status(500).json({ error: "Failed to fetch cards" });
    }
  });

  app.post("/api/cards/:userId", async (req, res) => {
    try {
      const { cardId } = req.body;
      if (!cardId) {
        return res.status(400).json({ error: "Card ID required" });
      }
      const card = await storage.addUserCard(req.params.userId, cardId);
      res.json({ card });
    } catch (error) {
      console.error("Add card error:", error);
      res.status(500).json({ error: "Failed to add card" });
    }
  });

  // Update user (for deck selection)
  app.patch("/api/users/:userId", async (req, res) => {
    try {
      const user = await storage.updateUser(req.params.userId, req.body);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      const { password, ...safeUser } = user;
      res.json({ user: safeUser });
    } catch (error) {
      console.error("Update user error:", error);
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  // Get all users (for trading)
  app.get("/api/users", async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const safeUsers = users.map(({ password, ...user }) => user);
      res.json({ users: safeUsers });
    } catch (error) {
      console.error("Get users error:", error);
      res.status(500).json({ error: "Failed to fetch users" });
    }
  });

  // Trades endpoints
  app.get("/api/trades", async (req, res) => {
    try {
      const trades = await storage.getTrades();
      res.json({ trades });
    } catch (error) {
      console.error("Get trades error:", error);
      res.status(500).json({ error: "Failed to fetch trades" });
    }
  });

  app.post("/api/trades", async (req, res) => {
    try {
      const { fromUserId, offeredCardIds, requestedCardIds } = req.body;
      if (!fromUserId || !offeredCardIds?.length) {
        return res.status(400).json({ error: "Missing required fields" });
      }
      const trade = await storage.createTrade({
        fromUserId,
        offeredCardIds,
        requestedCardIds: requestedCardIds || [],
        status: 'pending'
      });
      res.json({ trade });
    } catch (error) {
      console.error("Create trade error:", error);
      res.status(500).json({ error: "Failed to create trade" });
    }
  });

  app.patch("/api/trades/:id", async (req, res) => {
    try {
      const trade = await storage.updateTrade(req.params.id, req.body);
      if (!trade) {
        return res.status(404).json({ error: "Trade not found" });
      }
      res.json({ trade });
    } catch (error) {
      console.error("Update trade error:", error);
      res.status(500).json({ error: "Failed to update trade" });
    }
  });

  app.delete("/api/trades/:id", async (req, res) => {
    try {
      await storage.deleteTrade(req.params.id);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete trade error:", error);
      res.status(500).json({ error: "Failed to delete trade" });
    }
  });

  // Accept trade - execute the card swap
  app.post("/api/trades/:id/accept", async (req, res) => {
    try {
      const { acceptingUserId } = req.body;
      const trade = await storage.updateTrade(req.params.id, { 
        toUserId: acceptingUserId,
        status: 'accepted' 
      });
      
      if (!trade) {
        return res.status(404).json({ error: "Trade not found" });
      }
      
      // Transfer offered cards from sender to acceptor
      for (const cardId of trade.offeredCardIds) {
        await storage.removeUserCard(trade.fromUserId, cardId);
        await storage.addUserCard(acceptingUserId, cardId);
      }
      
      // Transfer requested cards from acceptor to sender (if any)
      if (trade.requestedCardIds?.length) {
        for (const cardId of trade.requestedCardIds) {
          await storage.removeUserCard(acceptingUserId, cardId);
          await storage.addUserCard(trade.fromUserId, cardId);
        }
      }
      
      res.json({ trade, success: true });
    } catch (error) {
      console.error("Accept trade error:", error);
      res.status(500).json({ error: "Failed to accept trade" });
    }
  });

  // AI Image editing endpoint - analyzes uploaded image and generates styled version
  app.post("/api/edit-image", async (req, res) => {
    try {
      const { image, style } = req.body;
      
      if (!image || !style) {
        return res.status(400).json({ error: "Image and style are required" });
      }
      
      // Validate style is from allowed list
      const allowedStyles = [
        'Cartoon/Anime', 'Oil Painting', 'Watercolor', 'Sketch/Pencil',
        'Pop Art', 'Vintage/Retro', 'Cyberpunk', 'Fantasy', 'Minimalist', 'Neon Glow'
      ];
      if (!allowedStyles.includes(style)) {
        return res.status(400).json({ error: "Invalid style selected" });
      }
      
      // Step 1: Use GPT-4 Vision to analyze and describe the uploaded image
      const visionResponse = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "user",
            content: [
              {
                type: "text",
                text: "Describe this image in detail for an artist to recreate it. Focus on: the main subject (person, object, scene), their pose/position, clothing/appearance, background elements, lighting, and mood. Be specific but concise (2-3 sentences)."
              },
              {
                type: "image_url",
                image_url: {
                  url: image,
                  detail: "low"
                }
              }
            ]
          }
        ],
        max_tokens: 200
      });
      
      const imageDescription = visionResponse.choices[0]?.message?.content || "A portrait scene";
      
      // Step 2: Generate a new image in the selected style based on the description
      const stylePrompt = `Create an artistic ${style} style image of: ${imageDescription}. 
        Make it a beautiful ${style} rendition with the characteristic aesthetic of ${style} art.
        The image should be vibrant, detailed, and clearly represent the ${style} artistic style.`;
      
      const response = await openai.images.generate({
        model: "gpt-image-1",
        prompt: stylePrompt,
        n: 1,
        size: "1024x1024",
      });
      
      const imageData = response.data?.[0];
      if (!imageData) {
        throw new Error("No image generated");
      }
      
      const imageUrl = imageData.url || imageData.b64_json;
      
      if (!imageUrl) {
        throw new Error("No image URL generated");
      }
      
      const finalUrl = imageData.b64_json 
        ? `data:image/png;base64,${imageData.b64_json}`
        : imageUrl;
      
      res.json({ imageUrl: finalUrl, description: imageDescription });
    } catch (error) {
      console.error("Image edit error:", error);
      res.status(500).json({ error: "Failed to edit image. Please try again." });
    }
  });

  return httpServer;
}
